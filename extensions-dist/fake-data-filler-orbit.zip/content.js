// Fake Data Filler — contenu injecté dans chaque page par l'extension Chrome.
// Remplit les champs de formulaire avec des données réalistes selon le type
// détecté (email, nom, téléphone, ville, date, etc.), comme Fake Filler
// (Chrome) ou Fake Data Filler (Firefox).
//
// Les types sont détectés depuis autocomplete/name/id/placeholder/aria-label
// ET depuis le <label> visible du champ — beaucoup de formulaires n'ont aucun
// indice ailleurs. Les valeurs par défaut sont des listes locales (aucune
// dépendance externe, aucune requête réseau) ; les Réglages d'Orbit peuvent
// fournir une liste par type, dans laquelle le 🎲 pioche au hasard.
// ---------------------------------------------------------------------------

(() => {
  'use strict';

  // ── Pont avec l'application (config personnalisée) ─────────────────────────
  // Le preload d'Orbit publie la config (champs personnalisés définis dans les
  // Réglages) dans le DOM : data-orbit-fake-data (JSON) + événement
  // 'orbit:fake-data'. On partage le DOM avec lui même si on tourne en monde
  // isolé. data-orbit-fake-enabled='1' signale que le fake data NATIF d'Orbit
  // est actif : dans ce cas on ne pose pas notre propre bouton 🎲 pour éviter
  // le doublon.
  let fakeCustom = {};
  let nativeActive = false;

  function readFakeCustomFromDom() {
    try {
      const raw = document.documentElement.getAttribute('data-orbit-fake-data');
      if (raw) {
        const parsed = JSON.parse(raw);
        if (parsed && typeof parsed === 'object') fakeCustom = parsed;
      }
      nativeActive =
        document.documentElement.getAttribute('data-orbit-fake-enabled') === '1';
    } catch {
      /* ignore */
    }
  }

  readFakeCustomFromDom();

  // Signaler au preload natif d'Orbit que CETTE extension est là : il
  // désactivera alors sa propre modale mot de passe et son bouton 🎲 (sinon
  // les deux panneaux se superposaient — même position — et « Utiliser »
  // remplissait une valeur différente de celle affichée). Un seul acteur.
  try {
    document.documentElement.setAttribute('data-orbit-fake-ext', '1');
  } catch {
    /* ignore */
  }
  window.addEventListener('orbit:fake-data', (e) => {
    if (e && e.detail && typeof e.detail === 'object') fakeCustom = e.detail;
    readFakeCustomFromDom();
  });

  // ── Outils utilitaires ─────────────────────────────────────────────────────

  const FAKE_TYPES = new Set([
    'text', 'email', 'tel', 'url', 'number', 'search', 'password', 'date',
    'datetime-local', 'month', 'week', 'time', 'range', 'color', 'checkbox',
    'radio', 'hidden', ''
  ]);

  const LOGIN_TYPE_SET = new Set(['text', 'email', 'password', '']);

  // Sous-ensemble des fields de connexion (identifiant + mot de passe). Les
  // champs qui correspondent à un type de connexion ET qui font partie d'un
  // formulaire de connexion ne seront pas remplis automatiquement par le 🎲
  // (pour ne pas mélanger remplissage identifiants et remplissage test).
  function reallyVisible(el) {
    if (!el || !el.offsetParent && el !== document.body) return false;
    const style = window.getComputedStyle(el);
    if (style.display === 'none' || style.visibility === 'hidden' || style.opacity === '0') return false;
    const rect = el.getBoundingClientRect();
    return rect.width > 0 && rect.height > 0;
  }

  function isFillable(el) {
    if (!el || !el.tagName) return false;
    const tag = el.tagName.toLowerCase();
    if (tag === 'textarea' || tag === 'select') {
      return reallyVisible(el) && !el.disabled && !el.readOnly;
    }
    if (el.isContentEditable || el.getAttribute('contenteditable') === 'true') {
      return reallyVisible(el);
    }

    if (tag !== 'input') return false;
    const t = (el.getAttribute('type') || 'text').toLowerCase();
    if (!FAKE_TYPES.has(t)) return false;
    if (['hidden', 'file', 'submit', 'reset', 'button', 'image'].includes(t)) return false;
    if (el.readOnly || el.disabled) return false;
    return reallyVisible(el);
  }

  function focusedField(event) {
    const path = typeof event.composedPath === 'function' ? event.composedPath() : [event.target];
    return path.find((node) => isFillable(node)) || document.activeElement;
  }

  function isLoginField(el) {
    if (el?.tagName?.toLowerCase() !== 'input') return false;
    const type = (el.getAttribute('type') || 'text').toLowerCase();
    if (!LOGIN_TYPE_SET.has(type)) return false;

    const autocomplete = el.autocomplete || '';
    if (/\b(?:username|current-password)\b/i.test(autocomplete)) return true;

    const form = el.form || el.closest('form');
    const loginScope = form || el.closest('dialog, [role="dialog"]');
    if (!loginScope) return false;
    const passwordFields = Array.from(loginScope.querySelectorAll('input[type="password"]')).filter(
      reallyVisible
    );
    return (
      passwordFields.length === 1 &&
      !/\bnew-password\b/i.test(passwordFields[0].autocomplete || '')
    );
  }

  // --- début bloc fake data partagé ---
  // Ce bloc est COPIÉ À L'IDENTIQUE dans electron/credentials-preload.cjs et dans
  // electron/extensions/fake-data-filler-orbit/content.js : le remplissage 🎲
  // doit deviner le même type de champ qu'on passe par le natif ou par
  // l'extension installée depuis le ZIP. test/fakeFieldKind.test.js extrait les
  // deux copies, vérifie qu'elles sont identiques et teste les règles.
  // Il ne dépend de rien : ni require, ni electronAPI, ni réseau.

  // Texte d'indice normalisé : accents retirés, camelCase et snake_case coupés
  // en mots, tout séparateur réduit à une espace. « Prénom », « firstName » et
  // « first_name » donnent tous le même texte, ce qui permet d'écrire les règles
  // sur des MOTS entiers (\b…\b) au lieu de chercher des morceaux au hasard —
  // c'est ce qui faisait prendre le « nom » de « prenom_2 » pour un patronyme.
  function fakeNorm(value) {
    return String(value == null ? '' : value)
      .replace(/([a-z0-9])([A-Z])/g, '$1 $2')
      .normalize('NFD')
      .replace(/[\u0300-\u036f]/g, '')
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, ' ')
      .trim();
  }

  function fakeAttr(el, name) {
    if (!el || typeof el.getAttribute !== 'function') return '';
    return el.getAttribute(name) || '';
  }

  function fakeShortText(value) {
    const text = String(value == null ? '' : value).replace(/\s+/g, ' ').trim();
    // Un « libellé » de 200 caractères est en réalité un paragraphe voisin : le
    // lire ferait entrer n'importe quel mot dans les indices.
    return text.length > 0 && text.length <= 120 ? text : '';
  }

  // Libellé visible d'un champ. C'est LA correction du « champ Nom rempli avec
  // du Lorem » : beaucoup de formulaires ne mettent aucun indice dans name/id
  // (« field_3 », « input-2 », des identifiants générés) et ne comptent que sur
  // le <label>. Sans ce texte, la détection n'avait rien à lire et retombait sur
  // « text ».
  function fakeLabelText(el) {
    if (!el) return '';
    const parts = [];
    const push = (value) => {
      const text = fakeShortText(value);
      if (text) parts.push(text);
    };

    try {
      // <label for="…"> : el.labels le fait nativement ; sinon on cherche.
      const labels = el.labels && el.labels.length ? Array.from(el.labels) : [];
      for (const label of labels) push(label.textContent);
      if (!labels.length && el.id && typeof document !== 'undefined') {
        const id =
          typeof CSS !== 'undefined' && CSS.escape
            ? CSS.escape(el.id)
            : String(el.id).replace(/["\\]/g, '\\$&');
        push(document.querySelector(`label[for="${id}"]`)?.textContent);
      }
    } catch {
      /* ignore */
    }

    try {
      // aria-labelledby et aria-describedby : le libellé est ailleurs dans la page.
      for (const attribute of ['aria-labelledby', 'aria-describedby']) {
        const ids = fakeAttr(el, attribute).split(/\s+/).filter(Boolean);
        for (const id of ids) {
          if (typeof document === 'undefined') break;
          push(document.getElementById(id)?.textContent);
        }
      }
    } catch {
      /* ignore */
    }

    try {
      // Champ enveloppé dans son libellé : <label>Nom <input></label>.
      if (typeof el.closest === 'function') {
        const wrapping = el.closest('label');
        if (wrapping) push(wrapping.textContent);
        const legend = el.closest('fieldset')?.querySelector?.('legend');
        if (legend) push(legend.textContent);
      }
    } catch {
      /* ignore */
    }

    try {
      // Dernier recours : le texte juste avant le champ (libellé posé en frère,
      // sans `for`). On ne remonte que de deux niveaux pour ne pas ramasser la
      // moitié du formulaire.
      let node = el;
      for (let depth = 0; depth < 2 && node; depth += 1) {
        const previous = node.previousElementSibling;
        const tag = previous && previous.tagName ? previous.tagName.toLowerCase() : '';
        if (['label', 'span', 'div', 'p', 'dt', 'th', 'strong', 'b'].includes(tag)) {
          push(previous.textContent);
          break;
        }
        node = node.parentElement;
      }
    } catch {
      /* ignore */
    }

    return parts.join(' ');
  }

  // Tous les indices d'un champ, normalisés. Les attributs des frameworks
  // (formControlName d'Angular, data-testid, v-model) portent souvent le seul
  // nom métier du champ.
  function fakeFieldHint(el) {
    if (!el) return '';
    return fakeNorm(
      [
        el.name,
        el.id,
        el.autocomplete || fakeAttr(el, 'autocomplete'),
        fakeAttr(el, 'placeholder'),
        fakeAttr(el, 'aria-label'),
        fakeAttr(el, 'title'),
        fakeAttr(el, 'data-testid'),
        fakeAttr(el, 'data-test'),
        fakeAttr(el, 'data-name'),
        fakeAttr(el, 'data-field'),
        fakeAttr(el, 'formcontrolname'),
        fakeAttr(el, 'ng-model'),
        fakeAttr(el, 'v-model'),
        fakeLabelText(el),
      ]
        .filter(Boolean)
        .join(' ')
    );
  }

  // `autocomplete` est la seule déclaration de type écrite par l'auteur de la
  // page : quand elle est là, elle passe avant toute devinette sur les libellés.
  const FAKE_AUTOCOMPLETE_KINDS = {
    'given-name': 'firstName',
    'additional-name': 'firstName',
    'family-name': 'lastName',
    name: 'fullName',
    'cc-name': 'fullName',
    nickname: 'username',
    username: 'username',
    email: 'email',
    tel: 'phone',
    'tel-national': 'phone',
    'tel-local': 'phone',
    organization: 'company',
    'organization-title': 'jobTitle',
    'street-address': 'address',
    'address-line1': 'address',
    'address-line2': 'address',
    'address-line3': 'address',
    'address-level1': 'region',
    'address-level2': 'city',
    'postal-code': 'zip',
    country: 'country',
    'country-name': 'country',
    bday: 'birthdate',
    sex: 'gender',
    url: 'url',
    photo: 'avatar',
    'cc-number': 'creditCard',
    'cc-exp': 'cardExpiry',
    'cc-csc': 'cardCvc',
  };

  function fakeAutocompleteKind(el) {
    const raw = String((el && (el.autocomplete || fakeAttr(el, 'autocomplete'))) || '')
      .toLowerCase()
      .trim();
    if (!raw || raw === 'on' || raw === 'off') return null;
    // « shipping street-address », « section-a billing postal-code » : seul le
    // dernier mot porte le type, mais on accepte n'importe quelle position.
    for (const token of raw.split(/\s+/)) {
      if (Object.prototype.hasOwnProperty.call(FAKE_AUTOCOMPLETE_KINDS, token)) {
        return FAKE_AUTOCOMPLETE_KINDS[token];
      }
    }
    return null;
  }

  // Règles de libellé, DANS L'ORDRE : la première qui correspond gagne. Les
  // pièges de « nom » et de « name » (nom d'utilisateur, nom de société, nom du
  // produit…) sont donc levés avant les règles larges.
  const FAKE_HINT_RULES = [
    // Identifiant de connexion : « nom d'utilisateur » n'est pas un nom.
    [/\b(nom (d |de |du )?(utilisateur|usager|compte|connexion)|user ?name|pseudo(nyme)?|login|identifiant|nickname|handle)\b/, 'username'],
    // Nom complet avant nom/prénom séparés.
    [/\b(nom complet|nom et prenom|prenom et nom|nom prenom|full ?name|complete name|your name|display name|nom affiche|titulaire|cardholder|name on card)\b/, 'fullName'],
    // Société avant « nom » : « nom de l'entreprise » est une société.
    [/\b(raison sociale|nom (de |d |de la |du )?(societe|entreprise|organisation|organisme|compagnie|boite|structure)|company|business name|societe|entreprise|organi[sz]ation|employeur|employer|siret|siren)\b/, 'company'],
    [/\b(prenom|first ?name|given ?name|forename)\b/, 'firstName'],
    [/\b(nom (de |d |de la )?(famille|naissance|jeune fille)|last ?name|surname|family ?name|patronyme)\b/, 'lastName'],
    // E-mail et téléphone.
    [/\b(e ?mail|mail|courriel)\b/, 'email'],
    [/\b(tel|telephone|phone|mobile|portable|gsm|whatsapp|cellulaire)\b/, 'phone'],
    // Images : l'avatar (une personne) avant les images décoratives.
    [/\b(avatar|profile pic\w*|profile image|profile photo|photo de profil|image de profil|portrait|headshot|trombinoscope)\b/, 'avatar'],
    [/\b(image|picture|photo|cover|banniere|banner|thumbnail|vignette|illustration|logo|affiche|visuel)\b/, 'image'],
    // Identité.
    [/\b(sexe|genre|gender|civilite)\b/, 'gender'],
    [/\b(date de naissance|birth ?date|date of birth|dob|birthday|anniversaire|ne le)\b/, 'birthdate'],
    [/\b(age)\b/, 'age'],
    // Paiement et banque : données de test, jamais de vraies coordonnées.
    [/\b(iban|rib)\b/, 'iban'],
    [/\b(card number|cc number|numero de carte|card ?no|ccnum|numero de la carte)\b/, 'creditCard'],
    [/\b(expir\w*|exp date|valid thru|date d expiration|mm yy|mm aa)\b/, 'cardExpiry'],
    [/\b(cvc|cvv|cvn|security code|cryptogramme)\b/, 'cardCvc'],
    // Adresse : le code postal et la ville avant « adresse », qui est large.
    [/\b(code postal|zip( code)?|postal code|postcode|cp)\b/, 'zip'],
    [/\b(ville|city|commune|localite|town)\b/, 'city'],
    [/\b(pays|country|nationalite|nationality)\b/, 'country'],
    [/\b(region|state|province|departement|county)\b/, 'region'],
    // « Adresse du site » est une URL, pas une rue : testé avant l'adresse.
    [/\b(site web|website|homepage|adresse (du |de la )?(site|page|web))\b/, 'url'],
    [/\b(adresse|address|rue|street|voie|avenue|boulevard|domicile)\b/, 'address'],
    // Métier, sujet, texte libre.
    [/\b(fonction|poste|job ?title|position|profession|occupation|metier|role)\b/, 'jobTitle'],
    [/\b(objet|subject|sujet|titre|title|motif)\b/, 'subject'],
    [/\b(description|commentaire|comment|message|bio|biographie|about|a propos|notes?|remarques?|details?|contenu|content|texte|body)\b/, 'lorem'],
    // « Nom du produit », « nom du fichier »… : un intitulé court, pas une
    // personne. Sans cette règle, le « nom » qui suit les enverrait sur un
    // patronyme.
    [/\bnom (du |de la |de l |des |d )?(produit|article|fichier|dossier|domaine|projet|tache|evenement|groupe|equipe|champ|colonne|categorie|rubrique|marque|modele|boutique|magasin|serveur|hote|reseau|wifi|carte|liste|modele)\b/, 'subject'],
    // Le nom tout court, en dernier : tout ce qui pouvait le désambiguïser a
    // déjà été essayé. « Nom » seul en français est un nom de famille ;
    // « name » seul en anglais est un nom complet.
    [/\b(nom)\b/, 'lastName'],
    [/\b(name)\b/, 'fullName'],
    // Site web après tout le reste : « url » apparaît dans beaucoup de champs.
    [/\b(site( web)?|website|homepage|url|lien|link|www)\b/, 'url'],
    [/\b(quantite|quantity|nombre|number|montant|amount|prix|price|numero|num)\b/, 'number'],
  ];

  function fakeHintKind(hint) {
    if (!hint) return null;
    for (const [pattern, kind] of FAKE_HINT_RULES) {
      if (pattern.test(hint)) return kind;
    }
    return null;
  }

  // Types dont la valeur reste écrivable dans un <input type="number"> : les
  // autres (une adresse, un nom) n'ont rien à y faire.
  const FAKE_NUMERIC_KINDS = new Set(['age', 'zip', 'phone', 'creditCard', 'cardCvc', 'number']);

  // Champ de fichier pouvant recevoir une image (avatar, couverture, produit).
  // Un `<input type="file" accept=".pdf">` n'est JAMAIS touché : on ne remplit
  // que les champs qui attendent une image (ou qui ne précisent rien).
  function acceptsFakeImage(el) {
    if (!el || !el.tagName || el.tagName.toLowerCase() !== 'input') return false;
    if (String(fakeAttr(el, 'type') || '').toLowerCase() !== 'file') return false;
    const accept = fakeAttr(el, 'accept').toLowerCase().trim();
    if (!accept) {
      // Aucun `accept` : on ne remplit que si le champ parle d'image. Sinon un
      // « déposez votre CV » recevrait un PNG.
      return /\b(avatar|photo|image|picture|portrait|logo|cover|banner|illustration|profil|visuel|vignette)\b/.test(
        fakeFieldHint(el)
      );
    }
    return accept
      .split(',')
      .map((part) => part.trim())
      .some((part) => part.startsWith('image/') || /\.(png|jpe?g|gif|webp|avif|bmp|svg)$/.test(part));
  }

  function detectFieldKind(el) {
    if (!el || !el.tagName) return 'text';
    const tag = el.tagName.toLowerCase();
    const type = String(fakeAttr(el, 'type') || el.type || 'text').toLowerCase().trim();

    if (type === 'password') return 'password';
    if (type === 'file') return acceptsFakeImage(el) ? 'imageFile' : 'file';
    if (type === 'checkbox') return 'boolean';
    if (type === 'radio') return 'choice';
    if (type === 'color') return 'color';

    // L'auteur de la page a déclaré le type : on le croit.
    const declared = fakeAutocompleteKind(el);
    const hint = fakeFieldHint(el);
    const guessed = fakeHintKind(hint);

    if (type === 'email') return 'email';
    if (type === 'tel') return 'phone';
    if (type === 'url') {
      // Un `<input type="url" name="avatarUrl">` attend une photo, pas un site.
      if (guessed === 'avatar' || guessed === 'image') return guessed;
      return declared === 'avatar' ? 'avatar' : 'url';
    }
    if (type === 'number' || type === 'range') {
      const kind = declared || guessed;
      return FAKE_NUMERIC_KINDS.has(kind) ? kind : 'number';
    }
    if (['date', 'datetime-local', 'month', 'week', 'time'].includes(type)) {
      // Une date de naissance doit tomber dans le passé, pas n'importe quand.
      return type === 'date' && (declared === 'birthdate' || guessed === 'birthdate')
        ? 'birthdate'
        : type;
    }

    if (declared) return declared;
    if (guessed) return guessed;

    if (tag === 'select') return 'choice';
    if (tag === 'textarea' || el.isContentEditable) return 'lorem';
    return 'text';
  }

  // --- Images de test -------------------------------------------------------
  // Un seul service donnait toujours la même sorte d'image. On tire au hasard
  // parmi plusieurs familles, pour que le remplissage ressemble à ce qu'on
  // rencontre vraiment : des initiales, un avatar dessiné, un portrait de stock,
  // un visage généré qui n'appartient à personne, un robot… Seule l'ADRESSE est
  // insérée ; c'est la page qui décide de la charger.
  //
  // Quand les photos sont coupées dans les Réglages (`photos: off`), plus aucun
  // service externe n'est appelé : l'image est DESSINÉE SUR PLACE et renvoyée en
  // data: URI. Elle s'affiche donc même hors ligne — là où l'ancienne adresse
  // d'exemple (example.com/avatar.png) ne montrait jamais rien.
  const FAKE_AVATAR_DIRS = ['women', 'men'];
  const FAKE_DICEBEAR_STYLES = [
    'lorelei', 'notionists', 'avataaars', 'personas', 'micah', 'open-peeps',
    'adventurer', 'miniavs', 'bottts', 'big-ears', 'fun-emoji', 'thumbs',
  ];
  const FAKE_ROBOHASH_SETS = ['set1', 'set2', 'set3', 'set4'];

  function fakePick(list) {
    return list[Math.floor(Math.random() * list.length)];
  }

  // Grain aléatoire : il change à chaque appel, donc deux remplissages de suite
  // ne donnent pas la même image (et le cache du navigateur ne s'en mêle pas).
  function fakeSeed() {
    return Math.random().toString(36).slice(2, 10);
  }

  function fakeInitials(first, last) {
    const letters = `${first || ''} ${last || ''}`
      .trim()
      .split(/\s+/)
      .map((word) => word[0])
      .filter(Boolean);
    return (letters.join('') || 'OT').slice(0, 2).toUpperCase();
  }

  function fakeLocalImageUrl(label, { square = false } = {}) {
    const hue = Math.floor(Math.random() * 360);
    const width = square ? 512 : 1200;
    const height = square ? 512 : 800;
    const text = String(label || '').replace(/[<>&"]/g, '');
    const svg =
      `<svg xmlns="http://www.w3.org/2000/svg" width="${width}" height="${height}" ` +
      `viewBox="0 0 ${width} ${height}">` +
      `<rect width="${width}" height="${height}" fill="hsl(${hue} 60% 46%)"/>` +
      `<text x="50%" y="50%" dy=".35em" text-anchor="middle" fill="#ffffff" ` +
      `font-family="system-ui, sans-serif" font-size="${square ? 220 : 110}">${text}</text></svg>`;
    return `data:image/svg+xml,${encodeURIComponent(svg)}`;
  }

  // Photo de profil. Le nom déjà tiré pour le formulaire sert de graine : les
  // initiales et l'avatar dessiné correspondent à la personne remplie.
  function fakeAvatarUrl(first, last, external) {
    if (!external) return fakeLocalImageUrl(fakeInitials(first, last), { square: true });
    const name = encodeURIComponent(`${first || 'Orbit'} ${last || 'Test'}`.trim());
    const seed = fakeSeed();
    return fakePick([
      // Initiales sur fond coloré (ui-avatars) : les « lettres ».
      () => `https://ui-avatars.com/api/?name=${name}&size=512&background=random`,
      // Avatar dessiné, déterministe pour une graine donnée (DiceBear).
      () => `https://api.dicebear.com/10.x/${fakePick(FAKE_DICEBEAR_STYLES)}/svg?seed=${seed}`,
      // Portraits de stock (Random User Generator).
      () =>
        `https://randomuser.me/api/portraits/${fakePick(FAKE_AVATAR_DIRS)}/${Math.floor(
          Math.random() * 100
        )}.jpg`,
      () => `https://i.pravatar.cc/512?u=${seed}`,
      // Visage généré : cette personne n'existe pas.
      () => `https://thispersondoesnotexist.com/random-person.jpeg?${seed}`,
      // Robot, alien ou chat (Robohash).
      () => `https://robohash.org/${seed}?set=${fakePick(FAKE_ROBOHASH_SETS)}&size=512x512`,
    ])();
  }

  // Image quelconque (couverture, illustration, photo de produit).
  function fakePictureUrl(external) {
    if (!external) return fakeLocalImageUrl('1200 × 800');
    const seed = fakeSeed();
    return fakePick([
      () => `https://picsum.photos/seed/${seed}/1200/800`,
      () => `https://placehold.co/1200x800?text=${encodeURIComponent('Image de test')}`,
      () => `https://dummyimage.com/1200x800/4f46e5/ffffff&text=${encodeURIComponent('Image de test')}`,
      () => `https://placecats.com/1200/800?${seed}`,
      () => `https://placedog.net/1200/800?random=${seed}`,
      () => `https://placebear.com/1200/800?${seed}`,
      () => `https://baconmockup.com/1200/800?${seed}`,
    ])();
  }

  // --- Valeurs personnalisées (Réglages) ------------------------------------
  // Trois sources possibles pour un type de champ, dans cet ordre :
  //   1. une LISTE de valeurs (`lists.city = ['Lyon', 'Nantes']`) → tirage au
  //      hasard dedans, ce qui permet du contenu varié mais maîtrisé ;
  //   2. une valeur unique (`city = 'Lyon'`, l'ancien format, toujours lu) ;
  //   3. rien → les listes intégrées à Orbit décident.
  // `source: 'builtin'` coupe 1 et 2 sans rien effacer : l'utilisateur garde ses
  // listes enregistrées et revient aux valeurs intégrées en un clic.
  function fakeCustomValues(config, kind) {
    if (!config || typeof config !== 'object' || !kind) return [];
    if (config.source === 'builtin') return [];
    const clean = (list) =>
      list.map((value) => String(value == null ? '' : value).trim()).filter(Boolean);

    const list = config.lists && config.lists[kind];
    if (Array.isArray(list)) {
      const values = clean(list);
      if (values.length) return values;
    } else if (typeof list === 'string') {
      // Une liste saisie dans une zone de texte : une valeur par ligne.
      const values = clean(list.split('\n'));
      if (values.length) return values;
    }

    // Ancien format : une valeur unique par type. Elle n'est PAS découpée en
    // lignes — le texte libre personnalisé est souvent un paragraphe.
    const single = config[kind];
    if (Array.isArray(single)) return clean(single);
    if (typeof single === 'string' && single.trim()) return [single.trim()];
    return [];
  }

  function fakeCustomValue(config, kind) {
    const values = fakeCustomValues(config, kind);
    if (!values.length) return null;
    return values[Math.floor(Math.random() * values.length)];
  }
  // --- fin bloc fake data partagé ---

  // ── Listes de données par défaut (locales, sans réseau) ────────────────────

  const FAKE_FIRST_NAMES = [
    'Camille', 'Alex', 'Marie', 'Lucas', 'Sofia', 'Noah', 'Emma', 'Léo', 'Jade', 'Adam',
    'Lina', 'Rayan', 'Chloé', 'Hugo', 'Zoe', 'Louis', 'Jules', 'Alice', 'Tom', 'Léa',
    'Gabriel', 'Maya', 'Raphaël', 'Eva', 'Nathan', 'Juliette', 'Arthur', 'Rose', 'Emile', 'Nina'
  ];

  const FAKE_LAST_NAMES = [
    'Martin', 'Bernard', 'Dubois', 'Robert', 'Petit', 'Durand', 'Leroy', 'Moreau', 'Roux', 'Blanc',
    'Garnier', 'Chevalier', 'Faure', 'Mercier', 'Richter', 'Lefebvre', 'Coste', 'Vincent', 'Duval', 'Muller'
  ];

  const FAKE_CITIES = [
    'Paris', 'Lyon', 'Marseille', 'Toulouse', 'Nantes', 'Bordeaux', 'Lille', 'Nice', 'Rennes',
    'Strasbourg', 'Montpellier', 'Toulon', 'Grenoble', 'Dijon', 'Reims', 'Le Havre', 'Saint-Étienne',
    'Metz', 'Bruxelles', 'Genève'
  ];

  const FAKE_STREETS = [
    '12 rue des Lilas', '8 avenue Victor Hugo', '25 boulevard Voltaire', '3 impasse du Moulin',
    '15 rue de la Paix', '7 place de la Mairie', '42 avenue des Champs-Élysées', '19 rue Gambetta',
    '6 rue du Faubourg Saint-Honoré', '23 cours de la Libération'
  ];

  const FAKE_COMPANIES = [
    'Orbit SAS', 'Nova Labs', 'Studio Meridian', 'Atelier Kairos', 'Groupe Lumen',
    'TechVista', 'Ecosystem Inc', 'CloudPeak', 'DataForge', 'SilicaNet'
  ];

  const FAKE_GENDERS = ['Femme', 'Homme', 'Non précisé'];
  const FAKE_COUNTRIES = ['France', 'Belgique', 'Suisse', 'Canada', 'Allemagne', 'Espagne', 'Italie', 'Portugal'];
  const FAKE_REGIONS = ['Île-de-France', 'Auvergne-Rhône-Alpes', 'Occitanie', 'Nouvelle-Aquitaine', 'Bretagne', 'Normandie'];
  const FAKE_JOBS = ['Product designer', 'Développeur logiciel', 'Chef de projet', 'Analyste de données', 'Responsable marketing', 'Technicien support'];
  const FAKE_SUBJECTS = ['Demande de démonstration', 'Question sur le produit', 'Retour utilisateur', 'Proposition de partenariat', 'Demande de renseignements'];
  const LOREM_WORDS = [
    'lorem', 'ipsum', 'dolor', 'sit', 'amet', 'consectetur', 'adipiscing', 'elit', 'integer',
    'vitae', 'justo', 'efficitur', 'congue', 'nunc', 'sagittis', 'sollicitudin', 'nullam',
    'mattis', 'ligula', 'euismod', 'viverra', 'mauris', 'aliquam', 'faucibus', 'vestibulum',
    'ornare', 'sapien', 'finibus', 'pulvinar', 'tempor', 'placerat', 'pharetra', 'rutrum',
    'facilisis', 'dictum', 'elementum', 'commodo', 'suscipit', 'hendrerit', 'varius', 'magna',
  ];

  function frand(arr) { return arr[Math.floor(Math.random() * arr.length)]; }
  function frandInt(n) { return Math.floor(Math.random() * n); }
  function loremText(minSentences = 2, maxSentences = 5) {
    const count = minSentences + frandInt(maxSentences - minSentences + 1);
    return Array.from({ length: count }, () => {
      const length = 7 + frandInt(12);
      const words = Array.from({ length }, () => frand(LOREM_WORDS));
      words[0] = words[0][0].toUpperCase() + words[0].slice(1);
      return `${words.join(' ')}.`;
    }).join(' ');
  }
  function fslug(s) {
    return String(s)
      .toLowerCase()
      .normalize('NFD')
      .replace(/[\u0300-\u036f]/g, '')
      .replace(/[^a-z]/g, '');
  }

  // ── Identité et paiement de test ──────────────────────────────────────────
  // Les images passent par le bloc partagé (plusieurs services au hasard, ou
  // une image dessinée sur place quand les photos sont coupées).
  const fakePhotosEnabled = () => fakeCustom.photos !== 'off';

  // IBAN français de test, VALIDE (clé ISO 13616 calculée par modulo 97) : les
  // formulaires qui vérifient l'IBAN avant d'envoyer acceptent la valeur.
  function fakeIban() {
    const bban = Array.from({ length: 23 }, () => frandInt(10)).join('');
    const rearranged = `${bban}FR00`.replace(/[A-Z]/g, (c) => String(c.charCodeAt(0) - 55));
    let rest = 0;
    for (const digit of rearranged) rest = (rest * 10 + Number(digit)) % 97;
    return `FR${String(98 - rest).padStart(2, '0')}${bban}`;
  }

  // Numéro de carte de test à 16 chiffres, VALIDE au sens de Luhn, préfixé
  // 4242 (le préfixe des cartes de test Visa) : refusé par les vrais
  // paiements, mais accepté par les formulaires qui vérifient la forme.
  function fakeCardNumber() {
    const base = `4242${Array.from({ length: 11 }, () => frandInt(10)).join('')}`;
    let sum = 0;
    for (let i = 0; i < base.length; i += 1) {
      let n = Number(base[base.length - 1 - i]);
      if (i % 2 === 0) {
        n *= 2;
        if (n > 9) n -= 9;
      }
      sum += n;
    }
    return `${base}${(10 - (sum % 10)) % 10}`;
  }

  function futureExpiry() {
    const month = 1 + frandInt(12);
    const year = (new Date().getFullYear() + 1 + frandInt(4)) % 100;
    return `${String(month).padStart(2, '0')}/${String(year).padStart(2, '0')}`;
  }

  function fakeBirthDate() {
    const date = new Date(Date.UTC(1950 + frandInt(55), frandInt(12), 1 + frandInt(28)));
    return date.toISOString().slice(0, 10);
  }

  // ── Générateur de mot de passe local (sans IPC) ────────────────────────────

  function generatePassword(length = 16) {
    const lower = 'abcdefghijklmnopqrstuvwxyz';
    const upper = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
    const digits = '0123456789';
    const symbols = '!@#$%^&*_-+=';

    const useSymbols = true;
    const allChars = lower + upper + digits + (useSymbols ? symbols : '');
    const mustInclude = useSymbols ? [lower, upper, digits, symbols] : [lower, upper, digits];

    // Garantie d'au moins un caractère de chaque catégorie requise
    let password = mustInclude.map((set) => set[Math.floor(Math.random() * set.length)]).join('');

    // Remplir jusqu'à la longueur souhaitée
    for (let i = password.length; i < length; i++) {
      password += allChars[Math.floor(Math.random() * allChars.length)];
    }

    // mélanger pour ne pas laisser les caractères obligatoires en début
    return password
      .split('')
      .sort(() => Math.random() - 0.5)
      .join('');
  }

  // ── Valeurs fake par type ──────────────────────────────────────────────────
  // Les valeurs personnalisées (Réglages d'Orbit) priment sur l'aléatoire,
  // exactement comme dans le fake data natif.
  function fakeValueFor(kind) {
    // Valeur (ou liste) personnalisée définie dans les Réglages : elle prime,
    // sauf si l'utilisateur a choisi les valeurs intégrées (`source: builtin`).
    const custom = fakeCustomValue(fakeCustom, kind);
    if (custom !== null) return custom;
    const first = fakeCustomValue(fakeCustom, 'firstName') || frand(FAKE_FIRST_NAMES);
    const last = fakeCustomValue(fakeCustom, 'lastName') || frand(FAKE_LAST_NAMES);

    switch (kind) {
      case 'password':
        return generatePassword(16);

      case 'email':
        return `${fslug(first)}.${fslug(last)}@example.com`;

      case 'firstName':
        return first;

      case 'lastName':
        return last;

      case 'fullName':
        return `${first} ${last}`;

      case 'username':
        return `${fslug(first)}${frandInt(1000)}`;

      case 'phone':
        return `06${String(frandInt(1e8)).padStart(8, '0')}`;

      case 'avatar':
        return fakeAvatarUrl(first, last, fakePhotosEnabled());

      case 'image':
        return fakePictureUrl(fakePhotosEnabled());

      case 'gender':
        return frand(FAKE_GENDERS);

      case 'birthdate':
        return fakeBirthDate();

      case 'age':
        return String(18 + frandInt(53));

      case 'iban':
        return fakeIban();

      case 'creditCard':
        return fakeCardNumber();

      case 'cardExpiry':
        return futureExpiry();

      case 'cardCvc':
        return String(100 + frandInt(900));

      case 'city':
        return FAKE_CITIES[frandInt(FAKE_CITIES.length)];

      case 'zip':
        return String(10000 + frandInt(89999));

      case 'address':
        return FAKE_STREETS[frandInt(FAKE_STREETS.length)];

      case 'company':
        return FAKE_COMPANIES[frandInt(FAKE_COMPANIES.length)];

      case 'country':
        return frand(FAKE_COUNTRIES);

      case 'region':
        return frand(FAKE_REGIONS);

      case 'jobTitle':
        return frand(FAKE_JOBS);

      case 'subject':
        return frand(FAKE_SUBJECTS);

      case 'url':
        return `https://${fslug(first)}-${fslug(last)}.example.com`;

      case 'number':
        return String(1 + frandInt(9999));

      case 'date':
      case 'datetime-local':
      case 'month':
      case 'week':
      case 'time': {
        const date = new Date(Date.now() - frandInt(3e10));
        if (kind === 'month') return date.toISOString().slice(0, 7);
        if (kind === 'week') {
          const firstDay = new Date(Date.UTC(date.getUTCFullYear(), 0, 1));
          const week = Math.ceil(((date - firstDay) / 86400000 + firstDay.getUTCDay() + 1) / 7);
          return `${date.getUTCFullYear()}-W${String(week).padStart(2, '0')}`;
        }
        if (kind === 'time') {
          return `${String(frandInt(24)).padStart(2, '0')}:${String(frandInt(60)).padStart(2, '0')}`;
        }
        if (kind === 'datetime-local') {
          return new Date(date.getTime() - date.getTimezoneOffset() * 60000).toISOString().slice(0, 16);
        }
        return date.toISOString().slice(0, 10);
      }

      case 'color':
        return `#${Math.floor(Math.random() * 0x1000000).toString(16).padStart(6, '0')}`;

      case 'lorem':
      case 'text':
      default:
        return loremText(kind === 'lorem' ? 3 : 1, kind === 'lorem' ? 6 : 3);

    }
  }

  // ── Modale mot de passe (comme le générateur natif d'Orbit) ──────────────
  // Même UX que le générateur du preload natif : mot de passe généré affiché,
  // MODIFIABLE à la main, boutons Utiliser / Non merci / ↻ régénérer. Les
  // styles sont posés en ligne : les pages embarquées imposent leur CSS.
  let pwPanel = null;

  function removePwPanel() {
    if (pwPanel) {
      pwPanel.remove();
      pwPanel = null;
    }
  }

  function showPasswordModal(fields) {
    removePwPanel();
    pwPanel = document.createElement('div');
    Object.assign(pwPanel.style, {
      position: 'fixed',
      top: '14px',
      right: '14px',
      zIndex: '2147483647',
      width: '320px',
      background: '#111827',
      border: '1px solid #374151',
      borderRadius: '12px',
      boxShadow: '0 12px 32px rgba(0,0,0,0.5)',
      fontFamily: 'system-ui, -apple-system, sans-serif',
      color: '#f3f4f6',
      padding: '14px',
      boxSizing: 'border-box',
    });

    const head = document.createElement('div');
    head.textContent = 'Mot de passe de test suggéré';
    Object.assign(head.style, { fontSize: '13px', fontWeight: '700', marginBottom: '2px' });
    pwPanel.appendChild(head);

    const sub = document.createElement('div');
    sub.textContent = 'Généré localement — modifiez-le si vous voulez.';
    Object.assign(sub.style, { fontSize: '12px', color: '#9ca3af', marginBottom: '10px' });
    pwPanel.appendChild(sub);

    // Champ MODIFIABLE (au lieu du div en lecture seule du natif)
    const input = document.createElement('input');
    input.type = 'text';
    input.value = generatePassword(16);
    input.spellcheck = false;
    Object.assign(input.style, {
      fontFamily: 'ui-monospace, SFMono-Regular, Menlo, monospace',
      fontSize: '13px',
      background: '#1f2937',
      border: '1px solid #374151',
      borderRadius: '8px',
      padding: '8px 10px',
      marginBottom: '10px',
      color: '#f3f4f6',
      width: '100%',
      boxSizing: 'border-box',
      outline: 'none',
    });
    input.addEventListener('focus', () => input.select());
    input.addEventListener('keydown', (e) => {
      if (e.key === 'Enter') {
        e.preventDefault();
        useBtn.click();
      }
      if (e.key === 'Escape') {
        e.preventDefault();
        removePwPanel();
      }
    });
    pwPanel.appendChild(input);

    const row = document.createElement('div');
    Object.assign(row.style, { display: 'flex', gap: '6px', alignItems: 'center' });

    // ↻ Régénérer
    const regen = document.createElement('button');
    regen.textContent = '↻';
    regen.title = 'Régénérer un mot de passe';
    Object.assign(regen.style, {
      padding: '7px 10px',
      borderRadius: '8px',
      border: '1px solid #374151',
      background: 'transparent',
      color: '#9ca3af',
      fontSize: '14px',
      cursor: 'pointer',
    });
    regen.addEventListener('click', () => {
      input.value = generatePassword(16);
      input.focus();
      input.select();
    });
    row.appendChild(regen);

    const useBtn = document.createElement('button');
    useBtn.textContent = 'Utiliser';
    Object.assign(useBtn.style, {
      flex: '1',
      padding: '7px 12px',
      borderRadius: '8px',
      border: 'none',
      background: '#6366f1',
      color: '#fff',
      fontSize: '12px',
      fontWeight: '600',
      cursor: 'pointer',
    });
    useBtn.addEventListener('click', () => {
      const val = input.value.trim();
      if (!val) return;
      // Remplit TOUS les champs passés (champ + confirmation éventuelle)
      fields.forEach((f) => {
        setValue(f, val);
        highlight(f);
      });
      showInfo(`Mot de passe de test inséré dans ${fields.length} champ(s)`);
      removePwPanel();
    });
    row.appendChild(useBtn);

    const dismiss = document.createElement('button');
    dismiss.textContent = 'Non merci';
    Object.assign(dismiss.style, {
      padding: '7px 12px',
      borderRadius: '8px',
      border: '1px solid #374151',
      background: 'transparent',
      color: '#9ca3af',
      fontSize: '12px',
      fontWeight: '600',
      cursor: 'pointer',
    });
    dismiss.addEventListener('click', removePwPanel);
    row.appendChild(dismiss);

    pwPanel.appendChild(row);
    document.body.appendChild(pwPanel);
    input.focus();
    input.select();
  }

  // Détection « formulaire d'inscription » : 2 champs mot de passe visibles
  // (mot de passe + confirmation), ou un seul avec autocomplete=new-password.
  // Dans ce cas la modale s'ouvre d'elle-même, une fois par page (comme natif).
  const PASSWORD_SELECTOR = 'input[type="password"]';

  function deepAll(sel) {
    // querySelectorAll ne voit pas le shadow DOM : on descend dedans à la main.
    const out = [];
    const walk = (root) => {
      try {
        root.querySelectorAll(sel).forEach((el) => out.push(el));
        root.querySelectorAll('*').forEach((el) => {
          if (el.shadowRoot) walk(el.shadowRoot);
        });
      } catch {
        /* ignore */
      }
    };
    walk(document);
    return out;
  }

  function isSignupForm() {
    const passes = deepAll(PASSWORD_SELECTOR).filter(reallyVisible);
    if (passes.length >= 2) return passes;
    const only = passes[0];
    if (only && /new-password/.test(only.autocomplete || '')) return passes;
    return null;
  }

  let signupShownFor = null;

  function maybeOfferSignupPassword() {
    const passes = isSignupForm();
    if (!passes) return;
    if (signupShownFor === location.href) return;
    signupShownFor = location.href;
    setTimeout(() => {
      if (isSignupForm()) showPasswordModal(passes);
    }, 600);
  }

  // ── Bouton 🎲 (overlay flottant) ──────────────────────────────────────────

  let fakeBtn = null;
  let fakeTimer = null;
  let scrollHandler = null;

  function removeFakeBtn() {
    if (fakeBtn) {
      fakeBtn.remove();
      fakeBtn = null;
    }
    if (scrollHandler) {
      document.removeEventListener('scroll', scrollHandler, true);
      scrollHandler = null;
    }
    clearTimeout(fakeTimer);
  }

  function positionFakeBtn(anchor) {
    if (!fakeBtn || !anchor) return;
    try {
      const r = anchor.getBoundingClientRect();
      let left = r.right + 5;
      if (left + 30 > window.innerWidth) left = Math.max(4, r.left - 31);
      const baseTop = r.top + r.height / 2 - 13;
      fakeBtn.style.left = left + 'px';
      fakeBtn.style.top = Math.max(4, baseTop) + 'px';
    } catch {
      /* ignore */
    }
  }

  function showFakeBtn(anchor) {
    removeFakeBtn();

    fakeBtn = document.createElement('button');
    fakeBtn.textContent = '\u{1F3B2}'; // 🎲
    fakeBtn.title = 'Remplir avec des données de test';

    Object.assign(fakeBtn.style, {
      position: 'fixed',
      zIndex: '2147483647',
      width: '26px',
      height: '26px',
      padding: '0',
      border: 'none',
      borderRadius: '7px',
      background: '#6366f1',
      cursor: 'pointer',
      fontSize: '14px',
      lineHeight: '26px',
      textAlign: 'center',
      boxShadow: '0 2px 8px rgba(0,0,0,0.35)',
      display: 'block',
      color: '#fff',
    });

    // mousedown preventDefault : ne pas voler le focus du champ avant de le remplir.
    fakeBtn.addEventListener('mousedown', (e) => e.preventDefault());

    fakeBtn.addEventListener('click', async (e) => {
      e.stopPropagation();
      e.preventDefault();
      // IMPORTANT : capturer l'ancre AVANT removeFakeBtn(), qui met fakeBtn à
      // null — lire fakeBtn._anchor après serait undefined et le clic ne
      // remplirait jamais le champ (bug silencieux).
      const button = fakeBtn;
      const anchorField = button?._anchor;
      removeFakeBtn();
      if (!anchorField || isLoginField(anchorField)) return;

      try {
        readFakeCustomFromDom();
        const kind = detectFieldKind(anchorField);

        // Champ mot de passe : modale (généré + modifiable + Utiliser),
        // exactement comme le générateur natif d'Orbit.
        if (kind === 'password') {
          const fields = deepAll(PASSWORD_SELECTOR).filter(reallyVisible);
          showPasswordModal(fields.length ? fields : [anchorField]);
          return;
        }

        const label = await fillElement(anchorField);
        highlight(anchorField);
        showInfo(`Valeur de test (${label}) insérée`);
      } catch (err) {
        console.error('[fake-data] erreur de remplissage :', err);
      }
      button._anchor = null;
    });

    fakeBtn.addEventListener('mouseenter', () => {
      fakeBtn.title = 'Remplir avec des données de test (\u{1F5D1}\u{FE0F} Alt+F)';
    });
    fakeBtn.addEventListener('mouseleave', () => {
      fakeBtn.title = 'Remplir avec des données de test';
    });

    document.body.appendChild(fakeBtn);
    positionFakeBtn(anchor);
    fakeBtn._anchor = anchor;

    scrollHandler = () => positionFakeBtn(anchor);
    document.addEventListener('scroll', scrollHandler, { capture: true, passive: true });

    fakeTimer = setTimeout(removeFakeBtn, 10000);
  }

  function showInfo(msg) {
    const existing = document.getElementById('__orbit_fake_info__');
    if (existing) existing.remove();

    const box = document.createElement('div');
    box.id = '__orbit_fake_info__';
    box.textContent = msg;
    Object.assign(box.style, {
      position: 'fixed',
      zIndex: '2147483647',
      left: '50%',
      bottom: '24px',
      transform: 'translateX(-50%)',
      maxWidth: 'min(560px, 90vw)',
      background: '#111827',
      color: '#f3f4f6',
      border: '1px solid #374151',
      borderRadius: '10px',
      padding: '10px 14px',
      fontFamily: 'system-ui, sans-serif',
      fontSize: '13px',
      boxShadow: '0 10px 30px rgba(0,0,0,0.5)',
      pointerEvents: 'none',
    });
    document.body.appendChild(box);
    setTimeout(() => box.remove(), 4000);
  }

  // ── Remplissage d'un champ ─────────────────────────────────────────────────

  function setValue(el, value) {
    if (!el || !el.tagName) return;
    // Le champ doit avoir le focus : certains frameworks ignorent une valeur
    // posée sur un champ « non touché ».
    try { el.focus(); } catch { /* ignore */ }
    try {
      if (el.isContentEditable || el.getAttribute('contenteditable') === 'true') {
        el.textContent = value;
      } else if (el.tagName.toLowerCase() === 'select') {
        el.value = value;
      } else {
        const proto =
          el instanceof HTMLTextAreaElement
            ? HTMLTextAreaElement.prototype
            : HTMLInputElement.prototype;
        const setter = Object.getOwnPropertyDescriptor(proto, 'value').set;
        if (el.type === 'date' && value && !isNaN(Date.parse(value))) {
            const d = new Date(value + 'T00:00:00');
            if (!isNaN(d.getTime())) el.valueAsDate = d;
            else setter.call(el, value);
        } else if (el.type === 'number' || el.type === 'range') {
          const n = parseFloat(value);
          setter.call(el, isNaN(n) ? value : n);
        } else {
          setter.call(el, value);
        }
      }
      // Même batterie d'événements que le fake data natif d'Orbit :
      // input/change couvrent React/Vue, keydown/keyup réveillent les
      // frameworks qui n'écoutent que le clavier.
      el.dispatchEvent(new InputEvent('beforeinput', { bubbles: true, inputType: 'insertText', data: value }));
      el.dispatchEvent(new Event('input', { bubbles: true }));
      el.dispatchEvent(new KeyboardEvent('keydown', { bubbles: true }));
      el.dispatchEvent(new KeyboardEvent('keyup', { bubbles: true }));
      el.dispatchEvent(new Event('change', { bubbles: true }));
    } catch {
      /* ignore */
    }
  }

  function dispatchFieldEvents(el, value = '') {
    el.dispatchEvent(new InputEvent('beforeinput', { bubbles: true, inputType: 'insertText', data: value }));
    el.dispatchEvent(new Event('input', { bubbles: true }));
    el.dispatchEvent(new Event('change', { bubbles: true }));
  }

  async function fillElement(el) {
    const tag = el.tagName?.toLowerCase();
    const type = (el.getAttribute('type') || el.type || 'text').toLowerCase();
    if (tag === 'select') {
      const options = Array.from(el.options || []).filter(
        (option) => !option.disabled && !option.hidden && option.value.trim()
      );
      if (!options.length) return 'select';
      if (el.multiple) {
        const count = 1 + frandInt(options.length);
        const selected = new Set(options.sort(() => Math.random() - 0.5).slice(0, count));
        for (const option of el.options) option.selected = selected.has(option);
      } else {
        const option = frand(options);
        el.value = option.value;
      }
      dispatchFieldEvents(el, el.value || '');
      return 'select';
    }

    if (type === 'checkbox') {
      el.checked = Math.random() >= 0.5;
      dispatchFieldEvents(el);
      return 'checkbox';
    }
    if (type === 'radio') {
      const group = el.name
        ? Array.from((el.form || document).querySelectorAll('input[type="radio"]')).filter(
            (radio) => radio.name === el.name && !radio.disabled && reallyVisible(radio)
          )
        : [el];
      const selected = group.length ? frand(group) : el;
      for (const radio of group) radio.checked = radio === selected;
      dispatchFieldEvents(selected);
      return 'radio';
    }

    const kind = detectFieldKind(el);
    if (type === 'range') {
      const min = el.min !== '' && Number.isFinite(Number(el.min)) ? Number(el.min) : 0;
      const max = el.max !== '' && Number.isFinite(Number(el.max)) ? Number(el.max) : 100;
      const step = Number(el.step) > 0 ? Number(el.step) : 1;
      const steps = Math.max(0, Math.floor((Math.max(min, max) - min) / step));
      const value = String(min + frandInt(steps + 1) * step);
      setValue(el, value);
    } else {
      setValue(el, await fakeValueFor(kind));
    }
    return kind;
  }

  function formFields(scope) {
    const fields = new Set(scope.elements ? Array.from(scope.elements) : []);
    const walk = (root) => {
      root.querySelectorAll?.('input, textarea, select, [contenteditable="true"], [contenteditable=""]').forEach(
        (el) => fields.add(el)
      );
      root.querySelectorAll?.('*').forEach((el) => {
        if (el.shadowRoot) walk(el.shadowRoot);
      });
    };
    walk(scope);
    return Array.from(fields);
  }

  async function fillFocusedForm(active) {
    const scope = active?.form || active?.closest?.('form, dialog, [role="dialog"]');
    if (!scope) return 0;
    const candidates = formFields(scope);
    if (!candidates.includes(active)) candidates.push(active);
    const fields = candidates.filter(
      (field) => isFillable(field) && !isLoginField(field)
    );
    if (!fields.length) return 0;

    const passwordFields = fields.filter(
      (field) => field.tagName?.toLowerCase() === 'input' &&
        (field.getAttribute('type') || '').toLowerCase() === 'password'
    );
    if (passwordFields.length) {
      const password = await fakeValueFor('password');
      for (const field of passwordFields) {
        setValue(field, password);
        highlight(field);
      }
    }

    const seenRadioGroups = new Map();
    let filled = passwordFields.length;
    for (const field of fields) {
      if (passwordFields.includes(field)) continue;
      if ((field.getAttribute('type') || '').toLowerCase() === 'radio') {
        const owner = field.form || scope;
        const name = field.name || field;
        let names = seenRadioGroups.get(owner);
        if (!names) {
          names = new Set();
          seenRadioGroups.set(owner, names);
        }
        if (names.has(name)) continue;
        names.add(name);
      }
      await fillElement(field);
      highlight(field);
      filled += 1;
    }
    return filled;
  }

  function highlight(el) {
    if (!el) return;
    try {
      el.style.transition = 'background 0.8s ease';
      el.style.background = 'rgba(99,102,241,0.25)';
      setTimeout(() => { el.style.background = ''; }, 900);
    } catch {
      /* ignore */
    }
  }

  // ── Hooks de focus ─────────────────────────────────────────────────────────

  document.addEventListener(
    'focusin',
    (e) => {
      const t = e.target;
      if (!t || typeof t.matches !== 'function') return;
      if (!isFillable(t) || isLoginField(t)) removeFakeBtn();
    },
    true
  );

  document.addEventListener(
    'focusin',
    (e) => {
      const t = e.target;
      if (!t) return;
      if (!isFillable(t) || isLoginField(t)) return;
      // Le fake data natif d'Orbit est déjà actif : il pose son propre bouton,
      // on ne pose pas le nôtre pour éviter le doublon.
      readFakeCustomFromDom();
      if (nativeActive) return;
      showFakeBtn(t);
    },
    true
  );

  document.addEventListener(
    'focusout',
    () => {
      setTimeout(() => {
        if (!document.activeElement || !isFillable(document.activeElement)) {
          removeFakeBtn();
        }
      }, 200);
    },
    true
  );

  // Raccourci clavier : Alt+F pour remplir le champ focalisé
  document.addEventListener('keydown', async (e) => {
    if (e.altKey && e.shiftKey && (e.key === 'f' || e.key === 'F')) {
      const active = focusedField(e);
      if (!active || !isFillable(active)) return;
      e.preventDefault();
      e.stopPropagation();
      removeFakeBtn();
      try {
        readFakeCustomFromDom();
        const count = await fillFocusedForm(active);
        showInfo(
          count
            ? `${count} champ(s) rempli(s) dans le formulaire actif (\u{1F5D1}\u{FE0F} Alt+Maj+F)`
            : 'Aucun champ remplissable dans le formulaire actif'
        );
      } catch (err) {
        console.error('[fake-data] erreur de remplissage du formulaire :', err);
      }
      return;
    }
    if (e.altKey && (e.key === 'f' || e.key === 'F')) {
      const active = document.activeElement;
      if (!active || !isFillable(active) || isLoginField(active)) return;
      e.preventDefault();
      e.stopPropagation();
      removeFakeBtn();

      const kind = detectFieldKind(active);
      // Mot de passe : modale au lieu d'un remplissage silencieux
      if (kind === 'password') {
        const fields = deepAll(PASSWORD_SELECTOR).filter(reallyVisible);
        showPasswordModal(fields.length ? fields : [active]);
        return;
      }

      try {
        const label = await fillElement(active);
        highlight(active);
        showInfo(`Valeur de test (${label}) insérée (\u{1F5D1}\u{FE0F} Alt+F)`);
      } catch (err) {
        console.error('[fake-data] erreur de remplissage :', err);
      }
    }
  });

  // Écouter la config qui change pendant qu'on est dans la page (champs
  // personnalisés modifiés dans les Réglages sans rechargement)
  document.addEventListener('focusin', () => readFakeCustomFromDom(), true);

  // ── Injection initiale : si un champ est déjà focalisé au chargement ──────

  if (
    document.activeElement &&
    isFillable(document.activeElement) &&
    !isLoginField(document.activeElement)
  ) {
    showFakeBtn(document.activeElement);
  }

  // Formulaire d'inscription détecté (2 champs mot de passe) : proposer la
  // modale une fois par page, comme le générateur natif.
  maybeOfferSignupPassword();
})();
