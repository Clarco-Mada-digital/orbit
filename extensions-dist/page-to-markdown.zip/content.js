// Page to Markdown — extension Chrome pour Orbit
// Convertit le contenu d'une page web en Markdown et le télécharge
// Compatibilité: content script seul, pas de background script

(() => {
  'use strict';

  // ── Convertisseurs HTML → Markdown (simple, sans dépendance) ──────────────

  function escapeMarkdown(text) {
    if (!text) return '';
    return text
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#39;');
  }

  function htmlToMarkdown(html, baseUrl = '') {
    const doc = html instanceof Document ? html : createTempDoc(html);
    return processElement(doc.body, baseUrl);
  }

  function createTempDoc(html) {
    const doc = document.implementation.createHTMLDocument('temp');
    doc.body.innerHTML = html;
    return doc;
  }

  function processElement(el, baseUrl, depth = 0) {
    if (!el || el.nodeType === Node.TEXT_NODE) {
      const text = el.textContent || '';
      return text.trim() ? escapeMarkdown(text) : '';
    }

    if (el.nodeType !== Node.ELEMENT_NODE) return '';

    const tag = el.tagName.toLowerCase();
    const style = el.style || {};
    const display = style.display || '';

    // Skip elements cachés
    if (display === 'none' || display === 'hidden') return '';

    // Skip les éléments non-utiles
    if (['SCRIPT', 'STYLE', 'NOSCRIPT', 'IFRAME', 'OBJECT', 'EMBED'].includes(tag)) {
      return '';
    }

    let md = '';

    switch (tag) {
      // ── Titres ──────────────────────────────────────────────────────────
      case 'h1': md += `# ${processChildren(el, baseUrl)}\n\n`; break;
      case 'h2': md += `## ${processChildren(el, baseUrl)}\n\n`; break;
      case 'h3': md += `### ${processChildren(el, baseUrl)}\n\n`; break;
      case 'h4': md += `#### ${processChildren(el, baseUrl)}\n\n`; break;
      case 'h5': md += `##### ${processChildren(el, baseUrl)}\n\n`; break;
      case 'h6': md += `###### ${processChildren(el, baseUrl)}\n\n`; break;

      // ── Formatage inline ────────────────────────────────────────────────
      case 'strong':
      case 'b':
        md += `**${processChildren(el, baseUrl)}**`;
        break;
      case 'em':
      case 'i':
        md += `_${processChildren(el, baseUrl)}_`;
        break;
      case 'u':
        md += `__${processChildren(el, baseUrl)}__`;
        break;
      case 's':
      case 'strike':
      case 'del':
        md += `~~${processChildren(el, baseUrl)}~~`;
        break;
      case 'code':
        if (el.parentElement && el.parentElement.tagName === 'PRE') {
          // Code block (géré avec pre)
          return '';
        }
        md += `\`${escapeMarkdown(processChildren(el, baseUrl))}\``;
        break;
      case 'pre':
        md += `\n\`\`\`\n${processChildren(el, baseUrl)}\n\`\`\`\n\n`;
        break;
      case 'br':
        md += '\n';
        break;
      case 'hr':
      case 'div':
        if (el.getAttribute('role') === 'separator' || el.getAttribute('aria-hidden') === 'true') {
          md += '\n---\n\n';
        } else {
          // Pour div, traiter les enfants
          md += processChildren(el, baseUrl);
        }
        break;
      case 'span':
        md += processChildren(el, baseUrl);
        break;

      // ── Liens ───────────────────────────────────────────────────────────
      case 'a': {
        const href = el.getAttribute('href') || '';
        const text = processChildren(el, baseUrl);
        if (href && text) {
          const fullUrl = href.startsWith('http') ? href : (baseUrl + href);
          md += `[${text}](${fullUrl})`;
        } else if (text) {
          md += text;
        }
        break;
      }

      // ── Images ──────────────────────────────────────────────────────────
      case 'img': {
        const src = el.getAttribute('src') || '';
        const alt = el.getAttribute('alt') || '';
        if (src) {
          const fullUrl = src.startsWith('http') ? src : (baseUrl + src);
          md += `![${escapeMarkdown(alt)}](${fullUrl})`;
        }
        break;
      }

      // ── Listes ──────────────────────────────────────────────────────────
      case 'ul': {
        md += '\n';
        const items = el.querySelectorAll('li');
        items.forEach(li => {
          md += `- ${processElement(li, baseUrl, depth + 1).trim()}\n`;
        });
        md += '\n';
        break;
      }
      case 'ol': {
        md += '\n';
        const items = el.querySelectorAll('li');
        items.forEach((li, i) => {
          md += `${i + 1}. ${processElement(li, baseUrl, depth + 1).trim()}\n`;
        });
        md += '\n';
        break;
      }
      case 'li': {
        // Gérer les listes imbriquées
        const nestedUl = el.querySelector('ul');
        const nestedOl = el.querySelectorAll('ol');
        if (nestedUl || nestedOl.length) {
          md += processChildren(el, baseUrl);

          if (nestedUl) {
            md += '\n';
            nestedUl.querySelectorAll('li').forEach(li => {
              md += `  - ${processElement(li, baseUrl, depth + 2).trim()}\n`;
            });
          }
          nestedOl.forEach(nested => {
            nested.querySelectorAll('li').forEach((li, i) => {
              md += `  ${i + 1}. ${processElement(li, baseUrl, depth + 2).trim()}\n`;
            });
          });
        } else {
          md += processChildren(el, baseUrl);
        }
        break;
      }

      // ── Tableaux ────────────────────────────────────────────────────────
      case 'table': {
        md += '\n';
        const rows = el.querySelectorAll('tr');
        rows.forEach((row, ri) => {
          const cells = row.querySelectorAll('th, td');
          const cellTexts = [];
          cells.forEach(cell => {
            cellTexts.push(processElement(cell, baseUrl, depth + 1).trim());
          });
          if (ri === 0 && row.querySelector('th')) {
            // En-tête
            md += cellTexts.map(c => c).join(' | ') + '\n';
            md += cellTexts.map(() => '---').join(' | ') + '\n';
          } else {
            md += cellTexts.map(c => c).join(' | ') + '\n';
          }
        });
        md += '\n';
        break;
      }

      // ── Blockquotes ─────────────────────────────────────────────────────
      case 'blockquote':
        md += '> ' + processChildren(el, baseUrl).replace(/\n/g, '\n> ') + '\n\n';
        break;

      // ── Formulaires (skip) ───────────────────────────────────────────────
      case 'form':
      case 'input':
      case 'textarea':
      case 'select':
      case 'button':
      case 'fieldset':
      case 'label':
        break;

      // ── Autres: traiter les enfants ─────────────────────────────────────
      default:
        md += processChildren(el, baseUrl);
    }

    return md;
  }

  function processChildren(el, baseUrl) {
    let result = '';
    for (let i = 0; i < el.childNodes.length; i++) {
      result += processElement(el.childNodes[i], baseUrl);
    }
    return result;
  }

  // ── Extraire le contenu principal de la page ──────────────────────────────

  function extractMainContent() {
    // Essayer de trouver le contenu principal
    const selectors = [
      'article',
      'main',
      '[role="main"]',
      '.content',
      '.post-content',
      '.entry-content',
      '.article-content',
      '#content',
      '#main',
      'body',
    ];

    for (const selector of selectors) {
      const el = document.querySelector(selector);
      if (el) {
        // Nettoyer: retirer nav, header, footer, aside si présent
        const clone = el.cloneNode(true);
        clone.querySelectorAll('nav, header, footer, aside, .sidebar, .comments, .related').forEach(el => el.remove());
        return clone;
      }
    }

    // Fallback: body entier
    return document.body;
  }

  // ── Générer le fichier Markdown ───────────────────────────────────────────

  function generateMarkdown() {
    const title = document.title || 'Page sans titre';
    const url = window.location.href;
    const date = new Date().toISOString().slice(0, 10);

    let md = `# ${escapeMarkdown(title)}\n\n`;
    md += `> Source: [${escapeMarkdown(url)}](${url})\n`;
    md += `> Sauvegardé le ${date}\n\n`;
    md += `---\n\n`;

    const mainContent = extractMainContent();
    const contentMd = htmlToMarkdown(mainContent, window.location.origin);
    md += contentMd;

    md += '\n---\n';
    md += `*Généré par Page to Markdown (Orbit)*\n`;

    return md;
  }

  // ── Télécharger le fichier ────────────────────────────────────────────────

  function downloadMarkdown(content, filename) {
    const blob = new Blob([content], { type: 'text/markdown;charset=utf-8' });
    const url = URL.createObjectURL(blob);

    const link = document.createElement('a');
    link.href = url;
    link.download = filename;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);

    setTimeout(() => URL.revokeObjectURL(url), 100);
  }

  // ── Afficher le panel de téléchargement ──────────────────────────────────

  function showDownloadPanel() {
    const existing = document.getElementById('__orbit_p2m_panel__');
    if (existing) existing.remove();

    const panel = document.createElement('div');
    panel.id = '__orbit_p2m_panel__';
    panel.style.cssText = `
      position: fixed;
      z-index: 2147483647;
      background: #1a1a2e;
      border: 1px solid #333;
      border-radius: 12px;
      padding: 16px;
      font-family: system-ui, sans-serif;
      font-size: 13px;
      color: #eee;
      box-shadow: 0 8px 32px rgba(0,0,0,0.5);
      max-width: 320px;
    `;

    const pageUrl = window.location.href;
    const filename = window.location.pathname
      .split('/')
      .filter(Boolean)
      .pop() || 'page';
    const safeFilename = filename.replace(/[^a-z0-9-]/gi, '_').toLowerCase() + '.md';

    panel.innerHTML = `
      <div style="font-weight: 600; margin-bottom: 12px; color: #888; font-size: 11px; text-transform: uppercase;">
        Page to Markdown
      </div>
      <div style="padding: 8px; background: #252540; border-radius: 6px; margin-bottom: 12px; word-break: break-all; font-size: 11px;">
        ${pageUrl}
      </div>
      <div style="font-size: 12px; color: #aaa; margin-bottom: 12px;">
        Contenu converti en Markdown (${safeFilename})
      </div>
      <div style="display: flex; gap: 8px;">
        <button id="__p2m_copy__"
          style="flex: 1; background: #6366f1; color: white; border: none;
                 border-radius: 6px; padding: 8px 12px; cursor: pointer; font-size: 12px;">
          Copier le Markdown
        </button>
        <button id="__p2m_dl__"
          style="flex: 1; background: #10b981; color: white; border: none;
                 border-radius: 6px; padding: 8px 12px; cursor: pointer; font-size: 12px;">
          Télécharger .md
        </button>
      </div>
    `;

    const right = window.innerWidth - 330;
    const top = 20;
    panel.style.right = Math.max(10, right) + 'px';
    panel.style.top = top + 'px';

    document.body.appendChild(panel);

    // Copier
    document.getElementById('__p2m_copy__').onclick = () => {
      const md = generateMarkdown();
      copyToClipboard(md);
      const btn = document.getElementById('__p2m_copy__');
      btn.textContent = '✓ Copié';
      btn.style.background = '#4ade80';
      setTimeout(() => {
        btn.textContent = 'Copier le Markdown';
        btn.style.background = '#6366f1';
      }, 2000);
    };

    // Télécharger
    document.getElementById('__p2m_dl__').onclick = () => {
      const md = generateMarkdown();
      downloadMarkdown(md, safeFilename);
      panel.remove();
    };

    // Fermer au clic extérieur
    const close = (e) => {
      if (!panel.contains(e.target)) {
        panel.remove();
        document.removeEventListener('mousedown', close);
      }
    };
    setTimeout(() => document.addEventListener('mousedown', close), 100);
  }

  function copyToClipboard(text) {
    if (navigator.clipboard && navigator.clipboard.writeText) {
      navigator.clipboard.writeText(text).catch(() => fallbackCopy(text));
    } else {
      fallbackCopy(text);
    }
  }

  function fallbackCopy(text) {
    const textarea = document.createElement('textarea');
    textarea.value = text;
    textarea.style.position = 'fixed';
    textarea.style.opacity = '0';
    document.body.appendChild(textarea);
    textarea.select();
    try { document.execCommand('copy'); } catch (e) {}
    document.body.removeChild(textarea);
  }

  // ── Ajout au menu contextuel d'Orbit (sans le remplacer) ─────────────
  // Protocole DOM (pas window.__orbitCtx) : les content scripts tournent dans
  // un « monde isolé » — leur window.__orbitCtx est invisible depuis le main
  // process. Le DOM est partagé : on écrit nos items dans
  // data-orbit-ctx quand Orbit diffuse 'orbit:ctx-refresh', et on exécute
  // l'action quand il diffuse 'orbit:ctx-action'.
  function registerCtx() {
    try {
      document.documentElement.setAttribute(
        'data-orbit-ctx',
        JSON.stringify([{ id: 'page2md', label: '📄 Convertir la page en Markdown' }])
      );
    } catch {
      /* ignore */
    }
  }

  registerCtx();
  document.documentElement.addEventListener('orbit:ctx-refresh', registerCtx);
  document.documentElement.addEventListener('orbit:ctx-action', (e) => {
    try {
      if (e.detail && e.detail.id === 'page2md') showDownloadPanel();
    } catch {
      /* ignore */
    }
  });

  // Raccourci clavier: Alt+M pour lancer la conversion
  document.addEventListener('keydown', (e) => {
    if (e.altKey && (e.key === 'm' || e.key === 'M')) {
      e.preventDefault();
      showDownloadPanel();
    }
  });

  console.log('[p2m] Page to Markdown activé (ajoute une option au clic droit)');
})();
