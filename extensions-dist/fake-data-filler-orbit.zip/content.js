// Fake Data Filler — contenu injecté dans chaque page par l'extension Chrome.
// Remplit les champs de formulaire avec des données réalistes selon le type
// détecté (email, nom, téléphone, ville, date, etc.), comme Fake Filler
// (Chrome) ou Fake Data Filler (Firefox).
//
// Les types sont détectés depuis autocomplete/name/id/placeholder/aria-label,
// exactement comme ces extensions. Les valeurs par défaut sont des listes
// locales (aucune dépendance externe, aucune requête réseau).
// ---------------------------------------------------------------------------

(() => {
  'use strict';

  // ── Pont avec l'application (config personnalisée) ─────────────────────────
  // Le preload d'Orbit publie la config (champs personnalisés définis dans les
  // Réglages) dans le DOM : data-orbit-fake-data (JSON) + événement
  // 'orbit:fake-data'. On partage le DOM avec lui même si on tourne en monde
  // isolé. data-orbit-fake-enabled='1' signale que le fake data NATIF d'Orbit
  // est actif : dans ce cas on ne pose pas notre propre bouton 🎲 pour éviter
  // le doublon.
  let fakeCustom = {};
  let nativeActive = false;

  function readFakeCustomFromDom() {
    try {
      const raw = document.documentElement.getAttribute('data-orbit-fake-data');
      if (raw) {
        const parsed = JSON.parse(raw);
        if (parsed && typeof parsed === 'object') fakeCustom = parsed;
      }
      nativeActive =
        document.documentElement.getAttribute('data-orbit-fake-enabled') === '1';
    } catch {
      /* ignore */
    }
  }

  readFakeCustomFromDom();

  // Signaler au preload natif d'Orbit que CETTE extension est là : il
  // désactivera alors sa propre modale mot de passe et son bouton 🎲 (sinon
  // les deux panneaux se superposaient — même position — et « Utiliser »
  // remplissait une valeur différente de celle affichée). Un seul acteur.
  try {
    document.documentElement.setAttribute('data-orbit-fake-ext', '1');
  } catch {
    /* ignore */
  }
  window.addEventListener('orbit:fake-data', (e) => {
    if (e && e.detail && typeof e.detail === 'object') fakeCustom = e.detail;
    readFakeCustomFromDom();
  });

  // ── Outils utilitaires ─────────────────────────────────────────────────────

  const FAKE_TYPES = new Set([
    'text', 'email', 'tel', 'url', 'number', 'search', 'password', 'date',
    'datetime-local', 'month', 'week', 'time', 'range', 'color', 'checkbox',
    'radio', 'hidden', ''
  ]);

  // Photos de test : portraits de stock (Random User Generator) et photos
  // quelconques (Lorem Picsum). Aucune clé, aucun compte ; seule l'URL est
  // insérée. « photos: off » (Réglages d'Orbit) coupe ces adresses.
  const FAKE_AVATAR_DIRS = ['women', 'men'];

  const LOGIN_TYPE_SET = new Set(['text', 'email', 'password', '']);

  // Sous-ensemble des fields de connexion (identifiant + mot de passe). Les
  // champs qui correspondent à un type de connexion ET qui font partie d'un
  // formulaire de connexion ne seront pas remplis automatiquement par le 🎲
  // (pour ne pas mélanger remplissage identifiants et remplissage test).
  function reallyVisible(el) {
    if (!el || !el.offsetParent && el !== document.body) return false;
    const style = window.getComputedStyle(el);
    if (style.display === 'none' || style.visibility === 'hidden' || style.opacity === '0') return false;
    const rect = el.getBoundingClientRect();
    return rect.width > 0 && rect.height > 0;
  }

  // Champ de fichier qui attend une image (avatar, couverture, produit). Un
  // `accept=".pdf"` n'est jamais touché : on ne remplace pas un document par
  // une image.
  function acceptsFakeImage(el) {
    if (el?.tagName?.toLowerCase() !== 'input') return false;
    if ((el.getAttribute('type') || '').toLowerCase() !== 'file') return false;
    const accept = (el.getAttribute('accept') || '').toLowerCase().trim();
    if (!accept) {
      // Aucun `accept` : on ne remplit que si le champ parle d'image. Sinon un
      // « déposez votre CV » recevrait un PNG.
      const hint = [
        el.name,
        el.id,
        el.placeholder,
        el.getAttribute('aria-label'),
        el.closest?.('label')?.textContent,
      ]
        .filter(Boolean)
        .join(' ')
        .toLowerCase();
      return /avatar|photo|image|picture|portrait|logo|cover|banner|illustration|profil/.test(hint);
    }
    return accept
      .split(',')
      .map((part) => part.trim())
      .some(
        (part) =>
          part.startsWith('image/') || /\.(png|jpe?g|gif|webp|avif|bmp|svg)$/.test(part)
      );
  }

  function isFillable(el) {
    if (!el || !el.tagName) return false;
    const tag = el.tagName.toLowerCase();
    if (tag === 'textarea' || tag === 'select') {
      return reallyVisible(el) && !el.disabled && !el.readOnly;
    }
    if (el.isContentEditable || el.getAttribute('contenteditable') === 'true') {
      return reallyVisible(el);
    }

    if (tag !== 'input') return false;
    const t = (el.getAttribute('type') || 'text').toLowerCase();
    if (t === 'file') return acceptsFakeImage(el) && !el.disabled && reallyVisible(el);
    if (!FAKE_TYPES.has(t)) return false;
    if (['hidden', 'submit', 'reset', 'button', 'image'].includes(t)) return false;
    if (el.readOnly || el.disabled) return false;
    return reallyVisible(el);
  }

  function focusedField(event) {
    const path = typeof event.composedPath === 'function' ? event.composedPath() : [event.target];
    return path.find((node) => isFillable(node)) || document.activeElement;
  }

  function isLoginField(el) {
    if (el?.tagName?.toLowerCase() !== 'input') return false;
    const type = (el.getAttribute('type') || 'text').toLowerCase();
    if (!LOGIN_TYPE_SET.has(type)) return false;

    const autocomplete = el.autocomplete || '';
    if (/\b(?:username|current-password)\b/i.test(autocomplete)) return true;

    const form = el.form || el.closest('form');
    const loginScope = form || el.closest('dialog, [role="dialog"]');
    if (!loginScope) return false;
    const passwordFields = Array.from(loginScope.querySelectorAll('input[type="password"]')).filter(
      reallyVisible
    );
    return (
      passwordFields.length === 1 &&
      !/\bnew-password\b/i.test(passwordFields[0].autocomplete || '')
    );
  }

  // Détection du type de champ (comme Fake Filler / Fill Millier)
  const HINT_ATTRS = [
    'autocomplete', 'name', 'id', 'placeholder',
    (el) => el.getAttribute && el.getAttribute('aria-label')
  ];

  function hintOf(el) {
    return HINT_ATTRS
      .map((a) => (typeof a === 'function' ? a(el) : el.getAttribute(a)))
      .filter(Boolean)
      .join(' ')
      .toLowerCase();
  }

  function detectFieldKind(el) {
    const type = (el.getAttribute('type') || el.type || 'text').toLowerCase().trim();
    // Indices lus avant les types : un `<input type="url" name="avatarUrl">`
    // attend une photo, pas un site web.
    const hint = hintOf(el);
    if (type === 'password') return 'password';
    if (type === 'email') return 'email';
    if (type === 'tel') return 'phone';
    if (type === 'url') {
      if (/avatar|profile.?pic|profile.?image|profile.?photo|photo.?de.?profil|image.?de.?profil|portrait|headshot/.test(hint))
        return 'avatar';
      if (/image|picture|photo|cover.?image|cover.?photo|banner|thumbnail|illustration|logo|affiche/.test(hint))
        return 'image';
      return 'url';
    }
    if (type === 'number') return 'number';
    if (type === 'file') return acceptsFakeImage(el) ? 'imageFile' : 'file';
    if (['date', 'datetime-local', 'month', 'week', 'time'].includes(type)) return type;
    if (type === 'range') return 'number';
    if (type === 'color') return 'color';
    if (type === 'checkbox') return 'boolean';
    if (type === 'radio') return 'choice';

    if (el.tagName?.toLowerCase() === 'textarea' || el.isContentEditable) return 'lorem';
    if (/e-?mail|courriel/.test(hint)) return 'email';
    if (/phone|t[eé]l|mobile|portable|whatsapp/.test(hint)) return 'phone';
    // Images : l'avatar (une personne) avant les images décoratives.
    if (/avatar|profile.?pic|profile.?image|profile.?photo|photo.?de.?profil|image.?de.?profil|portrait|headshot/.test(hint))
      return 'avatar';
    if (/image|picture|photo|cover.?image|cover.?photo|banner|thumbnail|illustration|logo|affiche/.test(hint))
      return 'image';
    // Identité
    if (/sexe|gender|genre/.test(hint)) return 'gender';
    if (/birth.?date|date.?of.?birth|\bdob\b|birthday|naissance/.test(hint)) return 'birthdate';
    if (/(^|[^a-z])age([^a-z]|$)/.test(hint) && !/message|image|page|usage|language|stage/.test(hint))
      return 'age';
    // Paiement / banque (données de test uniquement)
    if (/\biban\b/.test(hint)) return 'iban';
    if (/card.?number|cc.?number|num[eé]ro.?de.?carte|cardno|ccnum/.test(hint)) return 'creditCard';
    if (/expir|exp.?date|valid.?thru|date.?d.expiration|mm\s*\/?\s*yy/.test(hint)) return 'cardExpiry';
    if (/\b(cvc|cvv|cvn|security.?code|cryptogramme)\b/.test(hint)) return 'cardCvc';
    // Coordonnées et société (avant « name », trop large)
    if (/company|soci[eé]t[eé]|entreprise|organi[sz]ation/.test(hint)) return 'company';
    if (/country|pays/.test(hint)) return 'country';
    if (/state|province|r[eé]gion/.test(hint)) return 'region';
    if (/job.?title|position|poste|profession|occupation/.test(hint)) return 'jobTitle';
    if (/first.?name|pr[eé]nom|given/.test(hint)) return 'firstName';
    if (/((last.?name|surname|family)|(^|[^a-z])nom([^a-z]|$))/.test(hint) &&
        !/pr[eé]nom|user|soci|entreprise/.test(hint)) return 'lastName';
    if (/full.?name|fullname|your.?name|name|nom complet/.test(hint)) return 'fullName';
    if (/user.?name|pseudo|login|identifiant/.test(hint)) return 'username';
    if (/city|ville/.test(hint)) return 'city';
    if (/zip|postal|code.?postal|\bcp\b/.test(hint)) return 'zip';
    if (/address|adresse|street|rue/.test(hint)) return 'address';
    if (/website|homepage|url|site/.test(hint)) return 'url';
    if (/subject|objet/.test(hint)) return 'subject';
    if (/description|comment|message|bio|about|notes|detail|content|texte/.test(hint)) return 'lorem';
    if (el.tagName?.toLowerCase() === 'select') return 'choice';
    return 'text';
  }

  // ── Listes de données par défaut (locales, sans réseau) ────────────────────

  const FAKE_FIRST_NAMES = [
    'Camille', 'Alex', 'Marie', 'Lucas', 'Sofia', 'Noah', 'Emma', 'Léo', 'Jade', 'Adam',
    'Lina', 'Rayan', 'Chloé', 'Hugo', 'Zoe', 'Louis', 'Jules', 'Alice', 'Tom', 'Léa',
    'Gabriel', 'Maya', 'Raphaël', 'Eva', 'Nathan', 'Juliette', 'Arthur', 'Rose', 'Emile', 'Nina'
  ];

  const FAKE_LAST_NAMES = [
    'Martin', 'Bernard', 'Dubois', 'Robert', 'Petit', 'Durand', 'Leroy', 'Moreau', 'Roux', 'Blanc',
    'Garnier', 'Chevalier', 'Faure', 'Mercier', 'Richter', 'Lefebvre', 'Coste', 'Vincent', 'Duval', 'Muller'
  ];

  const FAKE_CITIES = [
    'Paris', 'Lyon', 'Marseille', 'Toulouse', 'Nantes', 'Bordeaux', 'Lille', 'Nice', 'Rennes',
    'Strasbourg', 'Montpellier', 'Toulon', 'Grenoble', 'Dijon', 'Reims', 'Le Havre', 'Saint-Étienne',
    'Metz', 'Bruxelles', 'Genève'
  ];

  const FAKE_STREETS = [
    '12 rue des Lilas', '8 avenue Victor Hugo', '25 boulevard Voltaire', '3 impasse du Moulin',
    '15 rue de la Paix', '7 place de la Mairie', '42 avenue des Champs-Élysées', '19 rue Gambetta',
    '6 rue du Faubourg Saint-Honoré', '23 cours de la Libération'
  ];

  const FAKE_COMPANIES = [
    'Orbit SAS', 'Nova Labs', 'Studio Meridian', 'Atelier Kairos', 'Groupe Lumen',
    'TechVista', 'Ecosystem Inc', 'CloudPeak', 'DataForge', 'SilicaNet'
  ];

  const FAKE_COUNTRIES = ['France', 'Belgique', 'Suisse', 'Canada', 'Allemagne', 'Espagne', 'Italie', 'Portugal'];
  const FAKE_REGIONS = ['Île-de-France', 'Auvergne-Rhône-Alpes', 'Occitanie', 'Nouvelle-Aquitaine', 'Bretagne', 'Normandie'];
  const FAKE_JOBS = ['Product designer', 'Développeur logiciel', 'Chef de projet', 'Analyste de données', 'Responsable marketing', 'Technicien support'];
  const FAKE_SUBJECTS = ['Demande de démonstration', 'Question sur le produit', 'Retour utilisateur', 'Proposition de partenariat', 'Demande de renseignements'];
  const LOREM_WORDS = [
    'lorem', 'ipsum', 'dolor', 'sit', 'amet', 'consectetur', 'adipiscing', 'elit', 'integer',
    'vitae', 'justo', 'efficitur', 'congue', 'nunc', 'sagittis', 'sollicitudin', 'nullam',
    'mattis', 'ligula', 'euismod', 'viverra', 'mauris', 'aliquam', 'faucibus', 'vestibulum',
    'ornare', 'sapien', 'finibus', 'pulvinar', 'tempor', 'placerat', 'pharetra', 'rutrum',
    'facilisis', 'dictum', 'elementum', 'commodo', 'suscipit', 'hendrerit', 'varius', 'magna',
  ];

  function frand(arr) { return arr[Math.floor(Math.random() * arr.length)]; }
  function frandInt(n) { return Math.floor(Math.random() * n); }

  function fakePhotosEnabled() { return fakeCustom.photos !== 'off'; }
  function portraitUrl() {
    return `https://randomuser.me/api/portraits/${frand(FAKE_AVATAR_DIRS)}/${frandInt(100)}.jpg`;
  }
  function pictureUrl() {
    return `https://picsum.photos/seed/${Math.random().toString(36).slice(2, 10)}/1200/800`;
  }

  // IBAN français de test VALIDE (clé ISO 13616 par modulo 97).
  function fakeIban() {
    const digits = (n) => Array.from({ length: n }, () => frandInt(10)).join('');
    const bban = digits(23);
    const rearranged = `${bban}FR00`.replace(/[A-Z]/g, (c) => String(c.charCodeAt(0) - 55));
    let rest = 0;
    for (const digit of rearranged) rest = (rest * 10 + Number(digit)) % 97;
    return `FR${String(98 - rest).padStart(2, '0')}${bban}`;
  }

  // Carte de test à 16 chiffres, VALIDE au sens de Luhn, préfixe 4242.
  function fakeCardNumber() {
    const base = `4242${Array.from({ length: 11 }, () => frandInt(10)).join('')}`;
    let sum = 0;
    for (let i = 0; i < base.length; i += 1) {
      let n = Number(base[base.length - 1 - i]);
      if (i % 2 === 0) {
        n *= 2;
        if (n > 9) n -= 9;
      }
      sum += n;
    }
    return `${base}${(10 - (sum % 10)) % 10}`;
  }

  function futureExpiry() {
    const month = 1 + frandInt(12);
    const year = (new Date().getFullYear() + 1 + frandInt(4)) % 100;
    return `${String(month).padStart(2, '0')}/${String(year).padStart(2, '0')}`;
  }

  function fakeBirthDate() {
    const date = new Date(Date.UTC(1950 + frandInt(55), frandInt(12), 1 + frandInt(28)));
    return date.toISOString().slice(0, 10);
  }
  function loremText(minSentences = 2, maxSentences = 5) {
    const count = minSentences + frandInt(maxSentences - minSentences + 1);
    return Array.from({ length: count }, () => {
      const length = 7 + frandInt(12);
      const words = Array.from({ length }, () => frand(LOREM_WORDS));
      words[0] = words[0][0].toUpperCase() + words[0].slice(1);
      return `${words.join(' ')}.`;
    }).join(' ');
  }
  function fslug(s) {
    return String(s)
      .toLowerCase()
      .normalize('NFD')
      .replace(/[\u0300-\u036f]/g, '')
      .replace(/[^a-z]/g, '');
  }

  // ── Générateur de mot de passe local (sans IPC) ────────────────────────────

  function generatePassword(length = 16) {
    const lower = 'abcdefghijklmnopqrstuvwxyz';
    const upper = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
    const digits = '0123456789';
    const symbols = '!@#$%^&*_-+=';

    const useSymbols = true;
    const allChars = lower + upper + digits + (useSymbols ? symbols : '');
    const mustInclude = useSymbols ? [lower, upper, digits, symbols] : [lower, upper, digits];

    // Garantie d'au moins un caractère de chaque catégorie requise
    let password = mustInclude.map((set) => set[Math.floor(Math.random() * set.length)]).join('');

    // Remplir jusqu'à la longueur souhaitée
    for (let i = password.length; i < length; i++) {
      password += allChars[Math.floor(Math.random() * allChars.length)];
    }

    // mélanger pour ne pas laisser les caractères obligatoires en début
    return password
      .split('')
      .sort(() => Math.random() - 0.5)
      .join('');
  }

  // ── Valeurs fake par type ──────────────────────────────────────────────────
  // Les valeurs personnalisées (Réglages d'Orbit) priment sur l'aléatoire,
  // exactement comme dans le fake data natif.
  function fakeValueFor(kind) {
    if (fakeCustom[kind]) return fakeCustom[kind];
    const first = fakeCustom.firstName || FAKE_FIRST_NAMES[frandInt(FAKE_FIRST_NAMES.length)];
    const last = fakeCustom.lastName || FAKE_LAST_NAMES[frandInt(FAKE_LAST_NAMES.length)];

    switch (kind) {
      case 'password':
        return generatePassword(16);

      case 'email':
        return fakeCustom.email || `${fslug(first)}.${fslug(last)}@example.com`;

      case 'firstName':
        return first;

      case 'lastName':
        return last;

      case 'fullName':
        return `${first} ${last}`;

      case 'username':
        return fakeCustom.username || `${fslug(first)}${frandInt(1000)}`;

      case 'phone':
        return fakeCustom.phone || `06${String(frandInt(1e8)).padStart(8, '0')}`;

      case 'avatar':
        return fakeCustom.avatar || (fakePhotosEnabled() ? portraitUrl() : 'https://example.com/avatar.png');

      case 'image':
        return fakeCustom.image || (fakePhotosEnabled() ? pictureUrl() : 'https://example.com/image.jpg');

      case 'gender':
        return frand(['Femme', 'Homme', 'Non précisé']);

      case 'birthdate':
        return fakeBirthDate();

      case 'age':
        return String(18 + frandInt(53));

      case 'iban':
        return fakeIban();

      case 'creditCard':
        return fakeCardNumber();

      case 'cardExpiry':
        return futureExpiry();

      case 'cardCvc':
        return String(100 + frandInt(900));

      case 'city':
        return fakeCustom.city || FAKE_CITIES[frandInt(FAKE_CITIES.length)];

      case 'zip':
        return fakeCustom.zip || String(10000 + frandInt(89999));

      case 'address':
        return fakeCustom.address || FAKE_STREETS[frandInt(FAKE_STREETS.length)];

      case 'company':
        return fakeCustom.company || FAKE_COMPANIES[frandInt(FAKE_COMPANIES.length)];

      case 'country':
        return frand(FAKE_COUNTRIES);

      case 'region':
        return frand(FAKE_REGIONS);

      case 'jobTitle':
        return frand(FAKE_JOBS);

      case 'subject':
        return frand(FAKE_SUBJECTS);

      case 'url':
        return `https://${fslug(first)}-${fslug(last)}.example.com`;

      case 'number':
        return String(1 + frandInt(9999));

      case 'imageFile':
        return '';

      case 'date':
      case 'datetime-local':
      case 'month':
      case 'week':
      case 'time': {
        const date = new Date(Date.now() - frandInt(3e10));
        if (kind === 'month') return date.toISOString().slice(0, 7);
        if (kind === 'week') {
          const firstDay = new Date(Date.UTC(date.getUTCFullYear(), 0, 1));
          const week = Math.ceil(((date - firstDay) / 86400000 + firstDay.getUTCDay() + 1) / 7);
          return `${date.getUTCFullYear()}-W${String(week).padStart(2, '0')}`;
        }
        if (kind === 'time') {
          return `${String(frandInt(24)).padStart(2, '0')}:${String(frandInt(60)).padStart(2, '0')}`;
        }
        if (kind === 'datetime-local') {
          return new Date(date.getTime() - date.getTimezoneOffset() * 60000).toISOString().slice(0, 16);
        }
        return date.toISOString().slice(0, 10);
      }

      case 'color':
        return `#${Math.floor(Math.random() * 0x1000000).toString(16).padStart(6, '0')}`;

      case 'lorem':
      case 'text':
      default:
        return fakeCustom.text || loremText(kind === 'lorem' ? 3 : 1, kind === 'lorem' ? 6 : 3);

    }
  }

  // ── Modale mot de passe (comme le générateur natif d'Orbit) ──────────────
  // Même UX que le générateur du preload natif : mot de passe généré affiché,
  // MODIFIABLE à la main, boutons Utiliser / Non merci / ↻ régénérer. Les
  // styles sont posés en ligne : les pages embarquées imposent leur CSS.
  let pwPanel = null;

  function removePwPanel() {
    if (pwPanel) {
      pwPanel.remove();
      pwPanel = null;
    }
  }

  function showPasswordModal(fields) {
    removePwPanel();
    pwPanel = document.createElement('div');
    Object.assign(pwPanel.style, {
      position: 'fixed',
      top: '14px',
      right: '14px',
      zIndex: '2147483647',
      width: '320px',
      background: '#111827',
      border: '1px solid #374151',
      borderRadius: '12px',
      boxShadow: '0 12px 32px rgba(0,0,0,0.5)',
      fontFamily: 'system-ui, -apple-system, sans-serif',
      color: '#f3f4f6',
      padding: '14px',
      boxSizing: 'border-box',
    });

    const head = document.createElement('div');
    head.textContent = 'Mot de passe de test suggéré';
    Object.assign(head.style, { fontSize: '13px', fontWeight: '700', marginBottom: '2px' });
    pwPanel.appendChild(head);

    const sub = document.createElement('div');
    sub.textContent = 'Généré localement — modifiez-le si vous voulez.';
    Object.assign(sub.style, { fontSize: '12px', color: '#9ca3af', marginBottom: '10px' });
    pwPanel.appendChild(sub);

    // Champ MODIFIABLE (au lieu du div en lecture seule du natif)
    const input = document.createElement('input');
    input.type = 'text';
    input.value = generatePassword(16);
    input.spellcheck = false;
    Object.assign(input.style, {
      fontFamily: 'ui-monospace, SFMono-Regular, Menlo, monospace',
      fontSize: '13px',
      background: '#1f2937',
      border: '1px solid #374151',
      borderRadius: '8px',
      padding: '8px 10px',
      marginBottom: '10px',
      color: '#f3f4f6',
      width: '100%',
      boxSizing: 'border-box',
      outline: 'none',
    });
    input.addEventListener('focus', () => input.select());
    input.addEventListener('keydown', (e) => {
      if (e.key === 'Enter') {
        e.preventDefault();
        useBtn.click();
      }
      if (e.key === 'Escape') {
        e.preventDefault();
        removePwPanel();
      }
    });
    pwPanel.appendChild(input);

    const row = document.createElement('div');
    Object.assign(row.style, { display: 'flex', gap: '6px', alignItems: 'center' });

    // ↻ Régénérer
    const regen = document.createElement('button');
    regen.textContent = '↻';
    regen.title = 'Régénérer un mot de passe';
    Object.assign(regen.style, {
      padding: '7px 10px',
      borderRadius: '8px',
      border: '1px solid #374151',
      background: 'transparent',
      color: '#9ca3af',
      fontSize: '14px',
      cursor: 'pointer',
    });
    regen.addEventListener('click', () => {
      input.value = generatePassword(16);
      input.focus();
      input.select();
    });
    row.appendChild(regen);

    const useBtn = document.createElement('button');
    useBtn.textContent = 'Utiliser';
    Object.assign(useBtn.style, {
      flex: '1',
      padding: '7px 12px',
      borderRadius: '8px',
      border: 'none',
      background: '#6366f1',
      color: '#fff',
      fontSize: '12px',
      fontWeight: '600',
      cursor: 'pointer',
    });
    useBtn.addEventListener('click', () => {
      const val = input.value.trim();
      if (!val) return;
      // Remplit TOUS les champs passés (champ + confirmation éventuelle)
      fields.forEach((f) => {
        setValue(f, val);
        highlight(f);
      });
      showInfo(`Mot de passe de test inséré dans ${fields.length} champ(s)`);
      removePwPanel();
    });
    row.appendChild(useBtn);

    const dismiss = document.createElement('button');
    dismiss.textContent = 'Non merci';
    Object.assign(dismiss.style, {
      padding: '7px 12px',
      borderRadius: '8px',
      border: '1px solid #374151',
      background: 'transparent',
      color: '#9ca3af',
      fontSize: '12px',
      fontWeight: '600',
      cursor: 'pointer',
    });
    dismiss.addEventListener('click', removePwPanel);
    row.appendChild(dismiss);

    pwPanel.appendChild(row);
    document.body.appendChild(pwPanel);
    input.focus();
    input.select();
  }

  // Détection « formulaire d'inscription » : 2 champs mot de passe visibles
  // (mot de passe + confirmation), ou un seul avec autocomplete=new-password.
  // Dans ce cas la modale s'ouvre d'elle-même, une fois par page (comme natif).
  const PASSWORD_SELECTOR = 'input[type="password"]';

  function deepAll(sel) {
    // querySelectorAll ne voit pas le shadow DOM : on descend dedans à la main.
    const out = [];
    const walk = (root) => {
      try {
        root.querySelectorAll(sel).forEach((el) => out.push(el));
        root.querySelectorAll('*').forEach((el) => {
          if (el.shadowRoot) walk(el.shadowRoot);
        });
      } catch {
        /* ignore */
      }
    };
    walk(document);
    return out;
  }

  function isSignupForm() {
    const passes = deepAll(PASSWORD_SELECTOR).filter(reallyVisible);
    if (passes.length >= 2) return passes;
    const only = passes[0];
    if (only && /new-password/.test(only.autocomplete || '')) return passes;
    return null;
  }

  let signupShownFor = null;

  function maybeOfferSignupPassword() {
    const passes = isSignupForm();
    if (!passes) return;
    if (signupShownFor === location.href) return;
    signupShownFor = location.href;
    setTimeout(() => {
      if (isSignupForm()) showPasswordModal(passes);
    }, 600);
  }

  // ── Bouton 🎲 (overlay flottant) ──────────────────────────────────────────

  let fakeBtn = null;
  let fakeTimer = null;
  let scrollHandler = null;

  function removeFakeBtn() {
    if (fakeBtn) {
      fakeBtn.remove();
      fakeBtn = null;
    }
    if (scrollHandler) {
      document.removeEventListener('scroll', scrollHandler, true);
      scrollHandler = null;
    }
    clearTimeout(fakeTimer);
  }

  function positionFakeBtn(anchor) {
    if (!fakeBtn || !anchor) return;
    try {
      const r = anchor.getBoundingClientRect();
      let left = r.right + 5;
      if (left + 30 > window.innerWidth) left = Math.max(4, r.left - 31);
      const baseTop = r.top + r.height / 2 - 13;
      fakeBtn.style.left = left + 'px';
      fakeBtn.style.top = Math.max(4, baseTop) + 'px';
    } catch {
      /* ignore */
    }
  }

  function showFakeBtn(anchor) {
    removeFakeBtn();

    fakeBtn = document.createElement('button');
    fakeBtn.textContent = '\u{1F3B2}'; // 🎲
    // Pas de `title` : l'infobulle native s'affichait sous le bouton et
    // recouvrait le champ voisin, notamment sur les selects et les recherches.
    fakeBtn.setAttribute('aria-label', 'Remplir avec des données de test (Alt+F)');

    Object.assign(fakeBtn.style, {
      position: 'fixed',
      zIndex: '2147483647',
      width: '26px',
      height: '26px',
      padding: '0',
      border: 'none',
      borderRadius: '7px',
      background: '#6366f1',
      cursor: 'pointer',
      fontSize: '14px',
      lineHeight: '26px',
      textAlign: 'center',
      boxShadow: '0 2px 8px rgba(0,0,0,0.35)',
      display: 'block',
      color: '#fff',
    });

    // mousedown preventDefault : ne pas voler le focus du champ avant de le remplir.
    fakeBtn.addEventListener('mousedown', (e) => e.preventDefault());

    fakeBtn.addEventListener('click', async (e) => {
      e.stopPropagation();
      e.preventDefault();
      // IMPORTANT : capturer l'ancre AVANT removeFakeBtn(), qui met fakeBtn à
      // null — lire fakeBtn._anchor après serait undefined et le clic ne
      // remplirait jamais le champ (bug silencieux).
      const button = fakeBtn;
      const anchorField = button?._anchor;
      removeFakeBtn();
      if (!anchorField || isLoginField(anchorField)) return;

      try {
        readFakeCustomFromDom();
        const kind = detectFieldKind(anchorField);

        // Champ mot de passe : modale (généré + modifiable + Utiliser),
        // exactement comme le générateur natif d'Orbit.
        if (kind === 'password') {
          const fields = deepAll(PASSWORD_SELECTOR).filter(reallyVisible);
          showPasswordModal(fields.length ? fields : [anchorField]);
          return;
        }

        const label = await fillElement(anchorField);
        highlight(anchorField);
        showInfo(`Valeur de test (${label}) insérée`);
      } catch (err) {
        console.error('[fake-data] erreur de remplissage :', err);
      }
      button._anchor = null;
    });

    document.body.appendChild(fakeBtn);
    positionFakeBtn(anchor);
    fakeBtn._anchor = anchor;

    scrollHandler = () => positionFakeBtn(anchor);
    document.addEventListener('scroll', scrollHandler, { capture: true, passive: true });

    fakeTimer = setTimeout(removeFakeBtn, 10000);
  }

  function showInfo(msg) {
    const existing = document.getElementById('__orbit_fake_info__');
    if (existing) existing.remove();

    const box = document.createElement('div');
    box.id = '__orbit_fake_info__';
    box.textContent = msg;
    Object.assign(box.style, {
      position: 'fixed',
      zIndex: '2147483647',
      left: '50%',
      bottom: '24px',
      transform: 'translateX(-50%)',
      maxWidth: 'min(560px, 90vw)',
      background: '#111827',
      color: '#f3f4f6',
      border: '1px solid #374151',
      borderRadius: '10px',
      padding: '10px 14px',
      fontFamily: 'system-ui, sans-serif',
      fontSize: '13px',
      boxShadow: '0 10px 30px rgba(0,0,0,0.5)',
      pointerEvents: 'none',
    });
    document.body.appendChild(box);
    setTimeout(() => box.remove(), 4000);
  }

  // ── Remplissage d'un champ ─────────────────────────────────────────────────

  function setValue(el, value) {
    if (!el || !el.tagName) return;
    // Le champ doit avoir le focus : certains frameworks ignorent une valeur
    // posée sur un champ « non touché ».
    try { el.focus(); } catch { /* ignore */ }
    try {
      if (el.isContentEditable || el.getAttribute('contenteditable') === 'true') {
        el.textContent = value;
      } else if (el.tagName.toLowerCase() === 'select') {
        el.value = value;
      } else {
        const proto =
          el instanceof HTMLTextAreaElement
            ? HTMLTextAreaElement.prototype
            : HTMLInputElement.prototype;
        const setter = Object.getOwnPropertyDescriptor(proto, 'value').set;
        if (el.type === 'date' && value && !isNaN(Date.parse(value))) {
            const d = new Date(value + 'T00:00:00');
            if (!isNaN(d.getTime())) el.valueAsDate = d;
            else setter.call(el, value);
        } else if (el.type === 'number' || el.type === 'range') {
          const n = parseFloat(value);
          setter.call(el, isNaN(n) ? value : n);
        } else {
          setter.call(el, value);
        }
      }
      // Même batterie d'événements que le fake data natif d'Orbit :
      // input/change couvrent React/Vue, keydown/keyup réveillent les
      // frameworks qui n'écoutent que le clavier.
      el.dispatchEvent(new InputEvent('beforeinput', { bubbles: true, inputType: 'insertText', data: value }));
      el.dispatchEvent(new Event('input', { bubbles: true }));
      el.dispatchEvent(new KeyboardEvent('keydown', { bubbles: true }));
      el.dispatchEvent(new KeyboardEvent('keyup', { bubbles: true }));
      el.dispatchEvent(new Event('change', { bubbles: true }));
    } catch {
      /* ignore */
    }
  }

  function dispatchFieldEvents(el, value = '') {
    el.dispatchEvent(new InputEvent('beforeinput', { bubbles: true, inputType: 'insertText', data: value }));
    el.dispatchEvent(new Event('input', { bubbles: true }));
    el.dispatchEvent(new Event('change', { bubbles: true }));
  }

  // ── Image de test pour <input type="file"> ────────────────────────────────
  // Dessinée LOCALEMENT dans un <canvas> (aucune requête réseau) puis injectée
  // comme un vrai fichier via DataTransfer : aperçus, contrôles de type et
  // envois multipart la voient comme un fichier choisi à la main.
  function fakeImageCanvas(el) {
    const square = /avatar|profile|portrait|photo|headshot|profil/i.test(
      [el.name, el.id, el.getAttribute('accept'), el.closest('label')?.textContent]
        .filter(Boolean)
        .join(' ')
    );
    const width = square ? 512 : 1200;
    const height = square ? 512 : 800;
    const canvas = document.createElement('canvas');
    canvas.width = width;
    canvas.height = height;
    const ctx = canvas.getContext('2d');
    if (!ctx) return null;

    const hue = frandInt(360);
    const gradient = ctx.createLinearGradient(0, 0, width, height);
    gradient.addColorStop(0, `hsl(${hue} 62% 52%)`);
    gradient.addColorStop(1, `hsl(${(hue + 48) % 360} 58% 32%)`);
    ctx.fillStyle = gradient;
    ctx.fillRect(0, 0, width, height);
    ctx.fillStyle = 'rgba(255,255,255,0.22)';
    if (square) {
      ctx.beginPath();
      ctx.arc(width / 2, height * 0.38, width * 0.17, 0, Math.PI * 2);
      ctx.fill();
      ctx.beginPath();
      ctx.ellipse(width / 2, height * 0.95, width * 0.34, height * 0.34, 0, Math.PI, 0);
      ctx.fill();
    } else {
      ctx.beginPath();
      ctx.arc(width * 0.76, height * 0.28, width * 0.09, 0, Math.PI * 2);
      ctx.fill();
      ctx.beginPath();
      ctx.ellipse(width * 0.3, height * 1.05, width * 0.55, height * 0.42, 0, Math.PI, 0);
      ctx.fill();
      ctx.fillStyle = 'rgba(255,255,255,0.14)';
      ctx.beginPath();
      ctx.ellipse(width * 0.8, height * 1.1, width * 0.5, height * 0.36, 0, Math.PI, 0);
      ctx.fill();
    }
    return canvas;
  }

  function fakeImageBlob(el) {
    const canvas = fakeImageCanvas(el);
    if (!canvas) return Promise.resolve(null);
    return new Promise((resolve) => {
      try {
        canvas.toBlob((blob) => resolve(blob), 'image/png');
      } catch {
        resolve(null);
      }
    });
  }

  async function fillImageFile(el) {
    const blob = await fakeImageBlob(el);
    if (!blob || typeof DataTransfer !== 'function') return false;
    try {
      const file = new File([blob], 'orbit-test.png', { type: 'image/png', lastModified: Date.now() });
      const transfer = new DataTransfer();
      transfer.items.add(file);
      el.files = transfer.files;
      dispatchFieldEvents(el);
      return true;
    } catch (err) {
      console.error('[fake-data] image de test impossible :', err);
      return false;
    }
  }

  async function fillElement(el) {
    const tag = el.tagName?.toLowerCase();
    const type = (el.getAttribute('type') || el.type || 'text').toLowerCase();
    if (type === 'file') {
      await fillImageFile(el);
      return 'image';
    }
    if (tag === 'select') {
      const options = Array.from(el.options || []).filter(
        (option) => !option.disabled && !option.hidden && option.value.trim()
      );
      if (!options.length) return 'select';
      if (el.multiple) {
        const count = 1 + frandInt(options.length);
        const selected = new Set(options.sort(() => Math.random() - 0.5).slice(0, count));
        for (const option of el.options) option.selected = selected.has(option);
      } else {
        const option = frand(options);
        el.value = option.value;
      }
      dispatchFieldEvents(el, el.value || '');
      return 'select';
    }

    if (type === 'checkbox') {
      el.checked = Math.random() >= 0.5;
      dispatchFieldEvents(el);
      return 'checkbox';
    }
    if (type === 'radio') {
      const group = el.name
        ? Array.from((el.form || document).querySelectorAll('input[type="radio"]')).filter(
            (radio) => radio.name === el.name && !radio.disabled && reallyVisible(radio)
          )
        : [el];
      const selected = group.length ? frand(group) : el;
      for (const radio of group) radio.checked = radio === selected;
      dispatchFieldEvents(selected);
      return 'radio';
    }

    const kind = detectFieldKind(el);
    if (type === 'range') {
      const min = el.min !== '' && Number.isFinite(Number(el.min)) ? Number(el.min) : 0;
      const max = el.max !== '' && Number.isFinite(Number(el.max)) ? Number(el.max) : 100;
      const step = Number(el.step) > 0 ? Number(el.step) : 1;
      const steps = Math.max(0, Math.floor((Math.max(min, max) - min) / step));
      const value = String(min + frandInt(steps + 1) * step);
      setValue(el, value);
    } else {
      setValue(el, await fakeValueFor(kind));
    }
    return kind;
  }

  function formFields(scope) {
    const fields = new Set(scope.elements ? Array.from(scope.elements) : []);
    const walk = (root) => {
      root.querySelectorAll?.('input, textarea, select, [contenteditable="true"], [contenteditable=""]').forEach(
        (el) => fields.add(el)
      );
      root.querySelectorAll?.('*').forEach((el) => {
        if (el.shadowRoot) walk(el.shadowRoot);
      });
    };
    walk(scope);
    return Array.from(fields);
  }

  async function fillFocusedForm(active) {
    const scope = active?.form || active?.closest?.('form, dialog, [role="dialog"]');
    if (!scope) return 0;
    const candidates = formFields(scope);
    if (!candidates.includes(active)) candidates.push(active);
    const fields = candidates.filter(
      (field) => isFillable(field) && !isLoginField(field)
    );
    if (!fields.length) return 0;

    const passwordFields = fields.filter(
      (field) => field.tagName?.toLowerCase() === 'input' &&
        (field.getAttribute('type') || '').toLowerCase() === 'password'
    );
    if (passwordFields.length) {
      const password = await fakeValueFor('password');
      for (const field of passwordFields) {
        setValue(field, password);
        highlight(field);
      }
    }

    const seenRadioGroups = new Map();
    let filled = passwordFields.length;
    for (const field of fields) {
      if (passwordFields.includes(field)) continue;
      if ((field.getAttribute('type') || '').toLowerCase() === 'radio') {
        const owner = field.form || scope;
        const name = field.name || field;
        let names = seenRadioGroups.get(owner);
        if (!names) {
          names = new Set();
          seenRadioGroups.set(owner, names);
        }
        if (names.has(name)) continue;
        names.add(name);
      }
      await fillElement(field);
      highlight(field);
      filled += 1;
    }
    return filled;
  }

  function highlight(el) {
    if (!el) return;
    try {
      el.style.transition = 'background 0.8s ease';
      el.style.background = 'rgba(99,102,241,0.25)';
      setTimeout(() => { el.style.background = ''; }, 900);
    } catch {
      /* ignore */
    }
  }

  // ── Hooks de focus ─────────────────────────────────────────────────────────

  document.addEventListener(
    'focusin',
    (e) => {
      const t = e.target;
      if (!t || typeof t.matches !== 'function') return;
      if (!isFillable(t) || isLoginField(t)) removeFakeBtn();
    },
    true
  );

  document.addEventListener(
    'focusin',
    (e) => {
      const t = e.target;
      if (!t) return;
      if (!isFillable(t) || isLoginField(t)) return;
      // Le fake data natif d'Orbit est déjà actif : il pose son propre bouton,
      // on ne pose pas le nôtre pour éviter le doublon.
      readFakeCustomFromDom();
      if (nativeActive) return;
      showFakeBtn(t);
    },
    true
  );

  document.addEventListener(
    'focusout',
    () => {
      setTimeout(() => {
        if (!document.activeElement || !isFillable(document.activeElement)) {
          removeFakeBtn();
        }
      }, 200);
    },
    true
  );

  // Raccourci clavier : Alt+F pour remplir le champ focalisé
  document.addEventListener('keydown', async (e) => {
    if (e.altKey && e.shiftKey && (e.key === 'f' || e.key === 'F')) {
      const active = focusedField(e);
      if (!active || !isFillable(active)) return;
      e.preventDefault();
      e.stopPropagation();
      removeFakeBtn();
      try {
        readFakeCustomFromDom();
        const count = await fillFocusedForm(active);
        showInfo(
          count
            ? `${count} champ(s) rempli(s) dans le formulaire actif (\u{1F5D1}\u{FE0F} Alt+Maj+F)`
            : 'Aucun champ remplissable dans le formulaire actif'
        );
      } catch (err) {
        console.error('[fake-data] erreur de remplissage du formulaire :', err);
      }
      return;
    }
    if (e.altKey && (e.key === 'f' || e.key === 'F')) {
      const active = document.activeElement;
      if (!active || !isFillable(active) || isLoginField(active)) return;
      e.preventDefault();
      e.stopPropagation();
      removeFakeBtn();

      const kind = detectFieldKind(active);
      // Mot de passe : modale au lieu d'un remplissage silencieux
      if (kind === 'password') {
        const fields = deepAll(PASSWORD_SELECTOR).filter(reallyVisible);
        showPasswordModal(fields.length ? fields : [active]);
        return;
      }

      try {
        const label = await fillElement(active);
        highlight(active);
        showInfo(`Valeur de test (${label}) insérée (\u{1F5D1}\u{FE0F} Alt+F)`);
      } catch (err) {
        console.error('[fake-data] erreur de remplissage :', err);
      }
    }
  });

  // Écouter la config qui change pendant qu'on est dans la page (champs
  // personnalisés modifiés dans les Réglages sans rechargement)
  document.addEventListener('focusin', () => readFakeCustomFromDom(), true);

  // ── Injection initiale : si un champ est déjà focalisé au chargement ──────

  if (
    document.activeElement &&
    isFillable(document.activeElement) &&
    !isLoginField(document.activeElement)
  ) {
    showFakeBtn(document.activeElement);
  }

  // Formulaire d'inscription détecté (2 champs mot de passe) : proposer la
  // modale une fois par page, comme le générateur natif.
  maybeOfferSignupPassword();
})();
