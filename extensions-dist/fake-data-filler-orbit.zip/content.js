// Fake Data Filler — contenu injecté dans chaque page par l'extension Chrome.
// Remplit les champs de formulaire avec des données réalistes selon le type
// détecté (email, nom, téléphone, ville, date, etc.), comme Fake Filler
// (Chrome) ou Fake Data Filler (Firefox).
//
// Les types sont détectés depuis autocomplete/name/id/placeholder/aria-label,
// exactement comme ces extensions. Les valeurs par défaut sont des listes
// locales (aucune dépendance externe, aucune requête réseau).
// ---------------------------------------------------------------------------

(() => {
  'use strict';

  // ── Pont avec l'application (config personnalisée) ─────────────────────────
  // Le preload d'Orbit publie la config (champs personnalisés définis dans les
  // Réglages) dans le DOM : data-orbit-fake-data (JSON) + événement
  // 'orbit:fake-data'. On partage le DOM avec lui même si on tourne en monde
  // isolé. data-orbit-fake-enabled='1' signale que le fake data NATIF d'Orbit
  // est actif : dans ce cas on ne pose pas notre propre bouton 🎲 pour éviter
  // le doublon.
  let fakeCustom = {};
  let nativeActive = false;

  function readFakeCustomFromDom() {
    try {
      const raw = document.documentElement.getAttribute('data-orbit-fake-data');
      if (raw) {
        const parsed = JSON.parse(raw);
        if (parsed && typeof parsed === 'object') fakeCustom = parsed;
      }
      nativeActive =
        document.documentElement.getAttribute('data-orbit-fake-enabled') === '1';
    } catch {
      /* ignore */
    }
  }

  readFakeCustomFromDom();

  // Signaler au preload natif d'Orbit que CETTE extension est là : il
  // désactivera alors sa propre modale mot de passe et son bouton 🎲 (sinon
  // les deux panneaux se superposaient — même position — et « Utiliser »
  // remplissait une valeur différente de celle affichée). Un seul acteur.
  try {
    document.documentElement.setAttribute('data-orbit-fake-ext', '1');
  } catch {
    /* ignore */
  }
  window.addEventListener('orbit:fake-data', (e) => {
    if (e && e.detail && typeof e.detail === 'object') fakeCustom = e.detail;
    readFakeCustomFromDom();
  });

  // ── Outils utilitaires ─────────────────────────────────────────────────────

  const FAKE_TYPES = new Set([
    'text', 'email', 'tel', 'url', 'number', 'search', 'password', 'date', ''
  ]);

  // Sous-ensemble des fields de connexion (identifiant + mot de passe). Les
  // champs qui correspondent à un type de connexion ET qui font partie d'un
  // formulaire de connexion ne seront pas remplis automatiquement par le 🎲
  // (pour ne pas mélanger remplissage identifiants et remplissage test).
  const LOGIN_TYPE_SET = new Set(['text', 'email', 'password', '']);

  function reallyVisible(el) {
    if (!el || !el.offsetParent && el !== document.body) return false;
    const style = window.getComputedStyle(el);
    if (style.display === 'none' || style.visibility === 'hidden' || style.opacity === '0') return false;
    const rect = el.getBoundingClientRect();
    return rect.width > 0 && rect.height > 0;
  }

  function isFillable(el) {
    if (!el || !el.tagName) return false;
    const tag = el.tagName.toLowerCase();
    if (tag === 'textarea') return reallyVisible(el);
    if (tag !== 'input') return false;
    const t = (el.getAttribute('type') || 'text').toLowerCase();
    if (!FAKE_TYPES.has(t)) return false;
    if (el.readOnly || el.disabled) return false;
    return reallyVisible(el);
  }

  // Détection du type de champ (comme Fake Filler / Fill Millier)
  const HINT_ATTRS = [
    'autocomplete', 'name', 'id', 'placeholder',
    (el) => el.getAttribute && el.getAttribute('aria-label')
  ];

  function hintOf(el) {
    return HINT_ATTRS
      .map((a) => (typeof a === 'function' ? a(el) : el.getAttribute(a)))
      .filter(Boolean)
      .join(' ')
      .toLowerCase();
  }

  function detectFieldKind(el) {
    const type = (el.getAttribute('type') || el.type || 'text').toLowerCase().trim();
    if (type === 'password') return 'password';
    if (type === 'email') return 'email';
    if (type === 'tel') return 'phone';
    if (type === 'url') return 'url';
    if (type === 'number') return 'number';
    if (type === 'date') return 'date';

    const hint = hintOf(el);
    if (/e-?mail|courriel/.test(hint)) return 'email';
    if (/phone|t[eé]l|mobile|portable|whatsapp/.test(hint)) return 'phone';
    if (/first.?name|pr[eé]nom|given/.test(hint)) return 'firstName';
    if (/((last.?name|surname|family)|(^|[^a-z])nom([^a-z]|$))/.test(hint) &&
        !/pr[eé]nom|user|soci|entreprise/.test(hint)) return 'lastName';
    if (/full.?name|fullname|your.?name|name|nom complet/.test(hint)) return 'fullName';
    if (/user.?name|pseudo|login|identifiant/.test(hint)) return 'username';
    if (/city|ville/.test(hint)) return 'city';
    if (/zip|postal|code.?postal|\bcp\b/.test(hint)) return 'zip';
    if (/address|adresse|street|rue/.test(hint)) return 'address';
    if (/company|soci[eé]t[eé]|entreprise|organi[sz]ation/.test(hint)) return 'company';
    if (/url|site|website/.test(hint)) return 'url';
    return 'text';
  }

  // ── Listes de données par défaut (locales, sans réseau) ────────────────────

  const FAKE_FIRST_NAMES = [
    'Camille', 'Alex', 'Marie', 'Lucas', 'Sofia', 'Noah', 'Emma', 'Léo', 'Jade', 'Adam',
    'Lina', 'Rayan', 'Chloé', 'Hugo', 'Zoe', 'Louis', 'Jules', 'Alice', 'Tom', 'Léa',
    'Gabriel', 'Maya', 'Raphaël', 'Eva', 'Nathan', 'Juliette', 'Arthur', 'Rose', 'Emile', 'Nina'
  ];

  const FAKE_LAST_NAMES = [
    'Martin', 'Bernard', 'Dubois', 'Robert', 'Petit', 'Durand', 'Leroy', 'Moreau', 'Roux', 'Blanc',
    'Garnier', 'Chevalier', 'Faure', 'Mercier', 'Richter', 'Lefebvre', 'Coste', 'Vincent', 'Duval', 'Muller'
  ];

  const FAKE_CITIES = [
    'Paris', 'Lyon', 'Marseille', 'Toulouse', 'Nantes', 'Bordeaux', 'Lille', 'Nice', 'Rennes',
    'Strasbourg', 'Montpellier', 'Toulon', 'Grenoble', 'Dijon', 'Reims', 'Le Havre', 'Saint-Étienne',
    'Metz', 'Bruxelles', 'Genève'
  ];

  const FAKE_STREETS = [
    '12 rue des Lilas', '8 avenue Victor Hugo', '25 boulevard Voltaire', '3 impasse du Moulin',
    '15 rue de la Paix', '7 place de la Mairie', '42 avenue des Champs-Élysées', '19 rue Gambetta',
    '6 rue du Faubourg Saint-Honoré', '23 cours de la Libération'
  ];

  const FAKE_COMPANIES = [
    'Orbit SAS', 'Nova Labs', 'Studio Meridian', 'Atelier Kairos', 'Groupe Lumen',
    'TechVista', 'Ecosystem Inc', 'CloudPeak', 'DataForge', 'SilicaNet'
  ];

  function frand(arr) { return arr[Math.floor(Math.random() * arr.length)]; }
  function frandInt(n) { return Math.floor(Math.random() * n); }
  function fslug(s) {
    return String(s)
      .toLowerCase()
      .normalize('NFD')
      .replace(/[\u0300-\u036f]/g, '')
      .replace(/[^a-z]/g, '');
  }

  // ── Générateur de mot de passe local (sans IPC) ────────────────────────────

  function generatePassword(length = 16) {
    const lower = 'abcdefghijklmnopqrstuvwxyz';
    const upper = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
    const digits = '0123456789';
    const symbols = '!@#$%^&*_-+=';

    const useSymbols = true;
    const allChars = lower + upper + digits + (useSymbols ? symbols : '');
    const mustInclude = useSymbols ? [lower, upper, digits, symbols] : [lower, upper, digits];

    // Garantie d'au moins un caractère de chaque catégorie requise
    let password = mustInclude.map((set) => set[Math.floor(Math.random() * set.length)]).join('');

    // Remplir jusqu'à la longueur souhaitée
    for (let i = password.length; i < length; i++) {
      password += allChars[Math.floor(Math.random() * allChars.length)];
    }

    // mélanger pour ne pas laisser les caractères obligatoires en début
    return password
      .split('')
      .sort(() => Math.random() - 0.5)
      .join('');
  }

  // ── Valeurs fake par type ──────────────────────────────────────────────────
  // Les valeurs personnalisées (Réglages d'Orbit) priment sur l'aléatoire,
  // exactement comme dans le fake data natif.
  function fakeValueFor(kind) {
    if (fakeCustom[kind]) return fakeCustom[kind];
    const first = fakeCustom.firstName || FAKE_FIRST_NAMES[frandInt(FAKE_FIRST_NAMES.length)];
    const last = fakeCustom.lastName || FAKE_LAST_NAMES[frandInt(FAKE_LAST_NAMES.length)];

    switch (kind) {
      case 'password':
        return generatePassword(16);

      case 'email':
        return fakeCustom.email || `${fslug(first)}.${fslug(last)}@example.com`;

      case 'firstName':
        return first;

      case 'lastName':
        return last;

      case 'fullName':
        return `${first} ${last}`;

      case 'username':
        return fakeCustom.username || `${fslug(first)}${frandInt(1000)}`;

      case 'phone':
        return fakeCustom.phone || `06${String(frandInt(1e8)).padStart(8, '0')}`;

      case 'city':
        return fakeCustom.city || FAKE_CITIES[frandInt(FAKE_CITIES.length)];

      case 'zip':
        return fakeCustom.zip || String(10000 + frandInt(89999));

      case 'address':
        return fakeCustom.address || FAKE_STREETS[frandInt(FAKE_STREETS.length)];

      case 'company':
        return fakeCustom.company || FAKE_COMPANIES[frandInt(FAKE_COMPANIES.length)];

      case 'url':
        return 'https://example.com';

      case 'number':
        return String(frandInt(100));

      case 'date':
        return new Date(Date.now() - frandInt(3e10)).toISOString().slice(0, 10);

      case 'text':
      default:
        // Données textuelles plus réalistes et variées (phrases complètes,
        // pas juste « Lorem »)
        return frand([
          'Ceci est un exemple de texte rempli automatiquement par Orbit.',
          'Voici une valeur de test pour ce champ de formulaire.',
          'Donnée générée aléatoirement pour les tests de saisie.',
          'Ce champ contient une valeur fictive à titre de démonstration.',
          'Exemple de contenu textuel utilisé pour le remplissage de formulaire.',
          'Donnée de test — remplacez par votre propre valeur lors de la saisie réelle.',
          'Valeur par défaut utilisée lors du remplissage automatique des champs.',
          'Ce texte est généré par Orbit pour illustrer le remplissage de données test.',
          'Description de produit : caractéristiques, contenu et informations pratiques.',
        ]);
    }
  }

  // ── Modale mot de passe (comme le générateur natif d'Orbit) ──────────────
  // Même UX que le générateur du preload natif : mot de passe généré affiché,
  // MODIFIABLE à la main, boutons Utiliser / Non merci / ↻ régénérer. Les
  // styles sont posés en ligne : les pages embarquées imposent leur CSS.
  let pwPanel = null;

  function removePwPanel() {
    if (pwPanel) {
      pwPanel.remove();
      pwPanel = null;
    }
  }

  function showPasswordModal(fields) {
    removePwPanel();
    pwPanel = document.createElement('div');
    Object.assign(pwPanel.style, {
      position: 'fixed',
      top: '14px',
      right: '14px',
      zIndex: '2147483647',
      width: '320px',
      background: '#111827',
      border: '1px solid #374151',
      borderRadius: '12px',
      boxShadow: '0 12px 32px rgba(0,0,0,0.5)',
      fontFamily: 'system-ui, -apple-system, sans-serif',
      color: '#f3f4f6',
      padding: '14px',
      boxSizing: 'border-box',
    });

    const head = document.createElement('div');
    head.textContent = 'Mot de passe de test suggéré';
    Object.assign(head.style, { fontSize: '13px', fontWeight: '700', marginBottom: '2px' });
    pwPanel.appendChild(head);

    const sub = document.createElement('div');
    sub.textContent = 'Généré localement — modifiez-le si vous voulez.';
    Object.assign(sub.style, { fontSize: '12px', color: '#9ca3af', marginBottom: '10px' });
    pwPanel.appendChild(sub);

    // Champ MODIFIABLE (au lieu du div en lecture seule du natif)
    const input = document.createElement('input');
    input.type = 'text';
    input.value = generatePassword(16);
    input.spellcheck = false;
    Object.assign(input.style, {
      fontFamily: 'ui-monospace, SFMono-Regular, Menlo, monospace',
      fontSize: '13px',
      background: '#1f2937',
      border: '1px solid #374151',
      borderRadius: '8px',
      padding: '8px 10px',
      marginBottom: '10px',
      color: '#f3f4f6',
      width: '100%',
      boxSizing: 'border-box',
      outline: 'none',
    });
    input.addEventListener('focus', () => input.select());
    input.addEventListener('keydown', (e) => {
      if (e.key === 'Enter') {
        e.preventDefault();
        useBtn.click();
      }
      if (e.key === 'Escape') {
        e.preventDefault();
        removePwPanel();
      }
    });
    pwPanel.appendChild(input);

    const row = document.createElement('div');
    Object.assign(row.style, { display: 'flex', gap: '6px', alignItems: 'center' });

    // ↻ Régénérer
    const regen = document.createElement('button');
    regen.textContent = '↻';
    regen.title = 'Régénérer un mot de passe';
    Object.assign(regen.style, {
      padding: '7px 10px',
      borderRadius: '8px',
      border: '1px solid #374151',
      background: 'transparent',
      color: '#9ca3af',
      fontSize: '14px',
      cursor: 'pointer',
    });
    regen.addEventListener('click', () => {
      input.value = generatePassword(16);
      input.focus();
      input.select();
    });
    row.appendChild(regen);

    const useBtn = document.createElement('button');
    useBtn.textContent = 'Utiliser';
    Object.assign(useBtn.style, {
      flex: '1',
      padding: '7px 12px',
      borderRadius: '8px',
      border: 'none',
      background: '#6366f1',
      color: '#fff',
      fontSize: '12px',
      fontWeight: '600',
      cursor: 'pointer',
    });
    useBtn.addEventListener('click', () => {
      const val = input.value.trim();
      if (!val) return;
      // Remplit TOUS les champs passés (champ + confirmation éventuelle)
      fields.forEach((f) => {
        setValue(f, val);
        highlight(f);
      });
      showInfo(`Mot de passe de test inséré dans ${fields.length} champ(s)`);
      removePwPanel();
    });
    row.appendChild(useBtn);

    const dismiss = document.createElement('button');
    dismiss.textContent = 'Non merci';
    Object.assign(dismiss.style, {
      padding: '7px 12px',
      borderRadius: '8px',
      border: '1px solid #374151',
      background: 'transparent',
      color: '#9ca3af',
      fontSize: '12px',
      fontWeight: '600',
      cursor: 'pointer',
    });
    dismiss.addEventListener('click', removePwPanel);
    row.appendChild(dismiss);

    pwPanel.appendChild(row);
    document.body.appendChild(pwPanel);
    input.focus();
    input.select();
  }

  // Détection « formulaire d'inscription » : 2 champs mot de passe visibles
  // (mot de passe + confirmation), ou un seul avec autocomplete=new-password.
  // Dans ce cas la modale s'ouvre d'elle-même, une fois par page (comme natif).
  const PASSWORD_SELECTOR = 'input[type="password"]';

  function deepAll(sel) {
    // querySelectorAll ne voit pas le shadow DOM : on descend dedans à la main.
    const out = [];
    const walk = (root) => {
      try {
        root.querySelectorAll(sel).forEach((el) => out.push(el));
        root.querySelectorAll('*').forEach((el) => {
          if (el.shadowRoot) walk(el.shadowRoot);
        });
      } catch {
        /* ignore */
      }
    };
    walk(document);
    return out;
  }

  function isSignupForm() {
    const passes = deepAll(PASSWORD_SELECTOR).filter(reallyVisible);
    if (passes.length >= 2) return passes;
    const only = passes[0];
    if (only && /new-password/.test(only.autocomplete || '')) return passes;
    return null;
  }

  let signupShownFor = null;

  function maybeOfferSignupPassword() {
    const passes = isSignupForm();
    if (!passes) return;
    if (signupShownFor === location.href) return;
    signupShownFor = location.href;
    setTimeout(() => {
      if (isSignupForm()) showPasswordModal(passes);
    }, 600);
  }

  // ── Bouton 🎲 (overlay flottant) ──────────────────────────────────────────

  let fakeBtn = null;
  let fakeTimer = null;
  let scrollHandler = null;

  function removeFakeBtn() {
    if (fakeBtn) {
      fakeBtn.remove();
      fakeBtn = null;
    }
    if (scrollHandler) {
      document.removeEventListener('scroll', scrollHandler, true);
      scrollHandler = null;
    }
    clearTimeout(fakeTimer);
  }

  function positionFakeBtn(anchor) {
    if (!fakeBtn || !anchor) return;
    try {
      const r = anchor.getBoundingClientRect();
      let left = r.right + 5;
      if (left + 30 > window.innerWidth) left = Math.max(4, r.left - 31);
      const baseTop = r.top + r.height / 2 - 13;
      fakeBtn.style.left = left + 'px';
      fakeBtn.style.top = Math.max(4, baseTop) + 'px';
    } catch {
      /* ignore */
    }
  }

  function showFakeBtn(anchor) {
    removeFakeBtn();

    fakeBtn = document.createElement('button');
    fakeBtn.textContent = '\u{1F3B2}'; // 🎲
    fakeBtn.title = 'Remplir avec des données de test';

    Object.assign(fakeBtn.style, {
      position: 'fixed',
      zIndex: '2147483647',
      width: '26px',
      height: '26px',
      padding: '0',
      border: 'none',
      borderRadius: '7px',
      background: '#6366f1',
      cursor: 'pointer',
      fontSize: '14px',
      lineHeight: '26px',
      textAlign: 'center',
      boxShadow: '0 2px 8px rgba(0,0,0,0.35)',
      display: 'block',
      color: '#fff',
    });

    // mousedown preventDefault : ne pas voler le focus du champ avant de le remplir.
    fakeBtn.addEventListener('mousedown', (e) => e.preventDefault());

    fakeBtn.addEventListener('click', async (e) => {
      e.stopPropagation();
      e.preventDefault();
      // IMPORTANT : capturer l'ancre AVANT removeFakeBtn(), qui met fakeBtn à
      // null — lire fakeBtn._anchor après serait undefined et le clic ne
      // remplirait jamais le champ (bug silencieux).
      const anchorField = fakeBtn._anchor;
      removeFakeBtn();
      if (!anchorField) return;

      try {
        readFakeCustomFromDom();
        const kind = detectFieldKind(anchorField);

        // Champ mot de passe : modale (généré + modifiable + Utiliser),
        // exactement comme le générateur natif d'Orbit.
        if (kind === 'password') {
          const fields = deepAll(PASSWORD_SELECTOR).filter(reallyVisible);
          showPasswordModal(fields.length ? fields : [anchorField]);
          return;
        }

        const value = fakeValueFor(kind);
        if (value !== undefined && value !== null) {
          setValue(anchorField, value);
          highlight(anchorField);
          showInfo(`Valeur de test (${kind}) insérée`);
        }
      } catch (err) {
        console.error('[fake-data] erreur de remplissage :', err);
      }
      fakeBtn._anchor = null;
    });

    fakeBtn.addEventListener('mouseenter', () => {
      fakeBtn.title = 'Remplir avec des données de test (\u{1F5D1}\u{FE0F} Alt+F)';
    });
    fakeBtn.addEventListener('mouseleave', () => {
      fakeBtn.title = 'Remplir avec des données de test';
    });

    document.body.appendChild(fakeBtn);
    positionFakeBtn(anchor);
    fakeBtn._anchor = anchor;

    scrollHandler = () => positionFakeBtn(anchor);
    document.addEventListener('scroll', scrollHandler, { capture: true, passive: true });

    fakeTimer = setTimeout(removeFakeBtn, 10000);
  }

  function showInfo(msg) {
    const existing = document.getElementById('__orbit_fake_info__');
    if (existing) existing.remove();

    const box = document.createElement('div');
    box.id = '__orbit_fake_info__';
    box.textContent = msg;
    Object.assign(box.style, {
      position: 'fixed',
      zIndex: '2147483647',
      left: '50%',
      bottom: '24px',
      transform: 'translateX(-50%)',
      maxWidth: 'min(560px, 90vw)',
      background: '#111827',
      color: '#f3f4f6',
      border: '1px solid #374151',
      borderRadius: '10px',
      padding: '10px 14px',
      fontFamily: 'system-ui, sans-serif',
      fontSize: '13px',
      boxShadow: '0 10px 30px rgba(0,0,0,0.5)',
      pointerEvents: 'none',
    });
    document.body.appendChild(box);
    setTimeout(() => box.remove(), 4000);
  }

  // ── Remplissage d'un champ ─────────────────────────────────────────────────

  function setValue(el, value) {
    if (!el || !el.tagName) return;
    // Le champ doit avoir le focus : certains frameworks ignorent une valeur
    // posée sur un champ « non touché ».
    try { el.focus(); } catch { /* ignore */ }
    try {
      const proto =
        el instanceof HTMLTextAreaElement
          ? HTMLTextAreaElement.prototype
          : HTMLInputElement.prototype;
      const setter = Object.getOwnPropertyDescriptor(proto, 'value').set;
      if (el.type === 'date' && value && !isNaN(Date.parse(value))) {
        const d = new Date(value + 'T00:00:00');
        if (!isNaN(d.getTime())) el.valueAsDate = d;
        else setter.call(el, value);
      } else if (el.type === 'number') {
        const n = parseFloat(value);
        setter.call(el, isNaN(n) ? value : n);
      } else {
        setter.call(el, value);
      }
      // Même batterie d'événements que le fake data natif d'Orbit :
      // input/change couvrent React/Vue, keydown/keyup réveillent les
      // frameworks qui n'écoutent que le clavier.
      el.dispatchEvent(new InputEvent('beforeinput', { bubbles: true, inputType: 'insertText', data: value }));
      el.dispatchEvent(new Event('input', { bubbles: true }));
      el.dispatchEvent(new KeyboardEvent('keydown', { bubbles: true }));
      el.dispatchEvent(new KeyboardEvent('keyup', { bubbles: true }));
      el.dispatchEvent(new Event('change', { bubbles: true }));
    } catch {
      /* ignore */
    }
  }

  function highlight(el) {
    if (!el) return;
    try {
      el.style.transition = 'background 0.8s ease';
      el.style.background = 'rgba(99,102,241,0.25)';
      setTimeout(() => { el.style.background = ''; }, 900);
    } catch {
      /* ignore */
    }
  }

  // ── Hooks de focus ─────────────────────────────────────────────────────────

  document.addEventListener(
    'focusin',
    (e) => {
      const t = e.target;
      if (!t || typeof t.matches !== 'function') return;
      if (!isFillable(t)) removeFakeBtn();
    },
    true
  );

  document.addEventListener(
    'focusin',
    (e) => {
      const t = e.target;
      if (!t) return;
      if (!isFillable(t)) return;
      // Le fake data natif d'Orbit est déjà actif : il pose son propre bouton,
      // on ne pose pas le nôtre pour éviter le doublon.
      readFakeCustomFromDom();
      if (nativeActive) return;
      showFakeBtn(t);
    },
    true
  );

  document.addEventListener(
    'focusout',
    () => {
      setTimeout(() => {
        if (!document.activeElement || !isFillable(document.activeElement)) {
          removeFakeBtn();
        }
      }, 200);
    },
    true
  );

  // Raccourci clavier : Alt+F pour remplir le champ focalisé
  document.addEventListener('keydown', (e) => {
    if (e.altKey && (e.key === 'f' || e.key === 'F')) {
      const active = document.activeElement;
      if (!active || !isFillable(active)) return;
      e.preventDefault();
      e.stopPropagation();
      removeFakeBtn();

      const kind = detectFieldKind(active);
      // Mot de passe : modale au lieu d'un remplissage silencieux
      if (kind === 'password') {
        const fields = deepAll(PASSWORD_SELECTOR).filter(reallyVisible);
        showPasswordModal(fields.length ? fields : [active]);
        return;
      }

      const value = fakeValueFor(kind);
      if (value !== undefined && value !== null) {
        setValue(active, value);
        highlight(active);
        showInfo(`Valeur de test (${kind}) insérée (\u{1F5D1}\u{FE0F} Alt+F)`);
      }
    }
  });

  // Écouter la config qui change pendant qu'on est dans la page (champs
  // personnalisés modifiés dans les Réglages sans rechargement)
  document.addEventListener('focusin', () => readFakeCustomFromDom(), true);

  // ── Injection initiale : si un champ est déjà focalisé au chargement ──────

  if (document.activeElement && isFillable(document.activeElement)) {
    showFakeBtn(document.activeElement);
  }

  // Formulaire d'inscription détecté (2 champs mot de passe) : proposer la
  // modale une fois par page, comme le générateur natif.
  maybeOfferSignupPassword();
})();
