// Color Picker — extension Chrome pour Orbit
// Pipette de couleur intégrée à la page : un bouton 🎨 flottant en bas à
// droite. Un clic active le « mode pipette » : survolez un élément pour voir
// sa couleur, cliquez pour la copier (Échap pour quitter). Raccourci : Alt+C.
// N'utilise PAS le menu contextuel (ne le remplace ni ne le complète).
//
// Compatibilité Orbit : content script seul, pas de background script.

(() => {
  'use strict';

  // ── Utilitaires de conversion de couleur ──────────────────────────────────

  function rgbToHex(r, g, b) {
    const toHex = (v) => {
      const h = Math.round(v).toString(16);
      return h.length === 1 ? '0' + h : h;
    };
    return `#${toHex(r)}${toHex(g)}${toHex(b)}`;
  }

  function parseCssColor(cssColor) {
    if (!cssColor || cssColor === 'transparent' || cssColor === 'rgba(0, 0, 0, 0)') {
      return null;
    }
    const rgbMatch = cssColor.match(/rgba?\((\d+),\s*(\d+),\s*(\d+)/);
    if (rgbMatch) {
      return rgbToHex(rgbMatch[1], rgbMatch[2], rgbMatch[3]);
    }
    // Couleur nommée (red, blue…) : on la résout via un élément temporaire
    const temp = document.createElement('div');
    temp.style.color = cssColor;
    document.body.appendChild(temp);
    const computed = window.getComputedStyle(temp).color;
    document.body.removeChild(temp);
    const rgbaMatch = computed.match(/rgba?\((\d+),\s*(\d+),\s*(\d+)/);
    if (rgbaMatch) {
      return rgbToHex(rgbaMatch[1], rgbaMatch[2], rgbaMatch[3]);
    }
    return null;
  }

  // Trouve la couleur la plus parlante d'un élément : fond d'abord, sinon texte.
  function colorOfElement(el) {
    if (!el || el.nodeType !== 1) return null;
    try {
      const styles = window.getComputedStyle(el);
      return (
        parseCssColor(styles.backgroundColor) ||
        parseCssColor(styles.color) ||
        parseCssColor(styles.borderColor) ||
        null
      );
    } catch {
      return null;
    }
  }

  // Copie au presse-papiers (avec repli)
  function copyToClipboard(text) {
    if (navigator.clipboard && navigator.clipboard.writeText) {
      navigator.clipboard.writeText(text).catch(() => fallbackCopy(text));
    } else {
      fallbackCopy(text);
    }
  }

  function fallbackCopy(text) {
    const textarea = document.createElement('textarea');
    textarea.value = text;
    textarea.style.position = 'fixed';
    textarea.style.opacity = '0';
    document.body.appendChild(textarea);
    textarea.select();
    try { document.execCommand('copy'); } catch (e) {}
    document.body.removeChild(textarea);
  }

  function showToast(msg) {
    const existing = document.getElementById('__orbit_color_toast__');
    if (existing) existing.remove();
    const box = document.createElement('div');
    box.id = '__orbit_color_toast__';
    box.textContent = msg;
    Object.assign(box.style, {
      position: 'fixed',
      zIndex: '2147483647',
      left: '50%',
      bottom: '24px',
      transform: 'translateX(-50%)',
      maxWidth: 'min(560px, 90vw)',
      background: '#111827',
      color: '#f3f4f6',
      border: '1px solid #374151',
      borderRadius: '10px',
      padding: '10px 14px',
      fontFamily: 'system-ui, sans-serif',
      fontSize: '13px',
      boxShadow: '0 10px 30px rgba(0,0,0,0.5)',
      pointerEvents: 'none',
    });
    document.body.appendChild(box);
    setTimeout(() => box.remove(), 2500);
  }

  // ── Bouton flottant 🎨 ─────────────────────────────────────────────────────

  let fab = null;
  let picking = false;
  let preview = null; // infobulle de couleur qui suit la souris
  let lastX = 0;
  let lastY = 0;

  function createFab() {
    if (fab) return;
    fab = document.createElement('button');
    fab.textContent = '🎨';
    fab.title = 'Color Picker — prélever une couleur (Alt+C)';
    fab.setAttribute('aria-label', 'Color Picker');
    Object.assign(fab.style, {
      position: 'fixed',
      zIndex: '2147483646',
      right: '16px',
      bottom: '16px',
      width: '40px',
      height: '40px',
      padding: '0',
      border: 'none',
      borderRadius: '12px',
      background: '#6366f1',
      cursor: 'pointer',
      fontSize: '20px',
      lineHeight: '40px',
      textAlign: 'center',
      boxShadow: '0 4px 16px rgba(0,0,0,0.35)',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      transition: 'transform 0.15s, background 0.15s',
      color: '#fff',
    });
    fab.addEventListener('mouseenter', () => {
      fab.style.transform = 'scale(1.08)';
    });
    fab.addEventListener('mouseleave', () => {
      fab.style.transform = 'scale(1)';
    });
    fab.addEventListener('click', (e) => {
      e.stopPropagation();
      e.preventDefault();
      togglePick();
    });
    document.body.appendChild(fab);
  }

  function removeFab() {
    if (fab) {
      fab.remove();
      fab = null;
    }
  }

  // ── Mode pipette ───────────────────────────────────────────────────────────

  function togglePick() {
    if (picking) endPick();
    else startPick();
  }

  function startPick() {
    picking = true;
    if (fab) {
      fab.style.background = '#10b981';
      fab.title = 'Color Picker — cliquez sur un élément (Échap pour quitter)';
    }
    document.documentElement.style.cursor = 'crosshair';
    preview = document.createElement('div');
    Object.assign(preview.style, {
      position: 'fixed',
      zIndex: '2147483647',
      pointerEvents: 'none',
      background: '#111827',
      color: '#f3f4f6',
      border: '1px solid #374151',
      borderRadius: '8px',
      padding: '6px 10px',
      fontFamily: 'system-ui, sans-serif',
      fontSize: '12px',
      boxShadow: '0 6px 20px rgba(0,0,0,0.45)',
      display: 'none',
      whiteSpace: 'nowrap',
    });
    document.body.appendChild(preview);
    document.addEventListener('mousemove', onMove, true);
    document.addEventListener('mousedown', onPick, true);
    document.addEventListener('keydown', onKey, true);
    showToast('🎨 Survolez un élément, cliquez pour copier sa couleur (Échap pour quitter)');
  }

  function endPick() {
    if (!picking) return;
    picking = false;
    document.documentElement.style.cursor = '';
    if (fab) {
      fab.style.background = '#6366f1';
      fab.title = 'Color Picker — prélever une couleur (Alt+C)';
    }
    if (preview) {
      preview.remove();
      preview = null;
    }
    document.removeEventListener('mousemove', onMove, true);
    document.removeEventListener('mousedown', onPick, true);
    document.removeEventListener('keydown', onKey, true);
  }

  function onMove(e) {
    lastX = e.clientX;
    lastY = e.clientY;
    if (!picking || !preview) return;
    const el = document.elementFromPoint(e.clientX, e.clientY);
    const color = el ? colorOfElement(el) : null;
    if (!color) {
      preview.style.display = 'none';
      return;
    }
    preview.textContent = color;
    preview.style.display = 'block';
    let left = e.clientX + 14;
    let top = e.clientY + 14;
    if (left + 120 > window.innerWidth) left = e.clientX - 130;
    if (top + 30 > window.innerHeight) top = e.clientY - 30;
    preview.style.left = left + 'px';
    preview.style.top = top + 'px';
  }

  function onPick(e) {
    if (!picking) return;
    e.preventDefault();
    e.stopPropagation();
    const el = document.elementFromPoint(e.clientX, e.clientY);
    const color = el ? colorOfElement(el) : null;
    endPick();
    if (color) {
      copyToClipboard(color);
      showToast(`🎨 Couleur ${color} copiée dans le presse-papiers`);
    } else {
      showToast('Aucune couleur détectée sur cet élément');
    }
  }

  function onKey(e) {
    if (e.key === 'Escape') {
      e.preventDefault();
      e.stopPropagation();
      endPick();
    }
  }

  // ── Raccourci clavier : Alt+C active/désactive la pipette ─────────────────

  document.addEventListener('keydown', (e) => {
    if (e.altKey && (e.key === 'c' || e.key === 'C')) {
      e.preventDefault();
      e.stopPropagation();
      togglePick();
    }
  });

  // ── Initialisation ─────────────────────────────────────────────────────────

  createFab();

  // Cacher le bouton dans les iframes invisibles (publicités…)
  const tryHideIfHidden = () => {
    try {
      if (window.self !== window.top && (!document.body || document.body.offsetWidth === 0)) {
        removeFab();
      }
    } catch {
      /* ignore */
    }
  };
  tryHideIfHidden();
  window.addEventListener('load', tryHideIfHidden);

  console.log('[color-picker] Color Picker activé (bouton 🎨 flottant, Alt+C)');
})();